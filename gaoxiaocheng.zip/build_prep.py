# -*- coding: utf-8 -*-
"""9月亚马逊搜索数据整体分析（SQP搜索查询绩效 × SP广告搜索词报告）"""
import pandas as pd, numpy as np, os, re, glob
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference

base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
cd = base + r'\产品9月份搜索查询绩效'
out = r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx'

# ============ 1. 读取 SQP ============
frames=[]
for f in glob.glob(cd+r'\*.csv'):
    d=pd.read_csv(f, skiprows=1, dtype=str)
    d['ASIN']=os.path.basename(f)[:-4]
    frames.append(d)
sqp=pd.concat(frames, ignore_index=True)
ncols={
 'score':'搜索查询得分','vol':'搜索查询量','m_impr':'曝光：曝光总量','o_impr':'曝光量：ASIN 计数','s_impr':'曝光：ASIN 曝光占比 %',
 'm_clk':'点击量：总次数','r_clk':'点击量：点击率 %','o_clk':'点击量：ASIN 数量','s_clk':'点击量：ASIN 份额 %',
 'm_add':'购物车添加：总数','r_add':'加入购物车：加购率%','o_add':'加购：ASIN 数量','s_add':'加入购物车：ASIN 加购占比 %',
 'm_ord':'购买：下单总数','r_ord':'下单成交：成交转化率%','o_ord':'下单成交：ASIN 数量','s_ord':'下单: ASIN 占比 %'}
for k,c in ncols.items():
    sqp[c]=pd.to_numeric(sqp[c], errors='coerce')
sqp=sqp.rename(columns={v:k for k,v in ncols.items()})
def norm(s): return re.sub(r'\s+',' ',str(s).strip().lower())
sqp['q']=sqp['搜索查询'].apply(norm)

mp=pd.read_excel(base+r'\对应关系.xlsx').dropna(subset=['ASIN'])
mp['ASIN']=mp['ASIN'].astype(str).str.strip()
namemap=dict(zip(mp['ASIN'],mp['品名'])); colormap=dict(zip(mp['ASIN'],mp['颜色'])); specmap=dict(zip(mp['ASIN'],mp['规格']))
sqp['品名']=sqp['ASIN'].map(namemap); sqp['颜色']=sqp['ASIN'].map(colormap); sqp['规格']=sqp['ASIN'].map(specmap)
def line_of(name):
    s=str(name)
    if '高硼硅' in s: return '高硼硅梅森罐'
    if '果茶' in s: return '梅森罐-果茶款'
    if '滤棒' in s: return '梅森罐-滤棒款'
    if '梅森罐32' in s: return '梅森罐-32oz'
    if '梅森罐64' in s: return '梅森罐-64oz'
    if '梅森罐' in s: return '梅森罐-其他'
    if '母乳罐' in s: return '母乳罐'
    if '水升' in s: return '水升/饮品壶'
    if '饮品罐' in s: return '饮品罐'
    if '洗衣罐' in s: return '洗衣罐'
    if '糖罐' in s: return '糖罐'
    if '圆形' in s or '方形' in s: return '玻璃保鲜套装'
    return '其他'
sqp['产品线']=sqp['品名'].apply(line_of)

# ============ 2. 读取广告报告 ============
ad=pd.read_excel(base+r'\26.9.xlsx')
adnum=['展示量','点击量','点击率 (CTR)','单次点击成本 (CPC)','花费','7天总销售额','广告投入产出比 (ACOS) 总计','总广告投资回报率 (ROAS)','7天总订单数(#)','7天总销售量(#)','7天的转化率','7天内广告SKU销售量(#)','7天内其他SKU销售量(#)','7天内广告SKU销售额','7天内其他SKU销售额']
for c in adnum: ad[c]=pd.to_numeric(ad[c],errors='coerce')
ad['q']=ad['客户搜索词'].dropna().apply(norm)
ad['开始日期']=pd.to_datetime(ad['开始日期'])
mt={'EXACT':'精准匹配','PHRASE':'词组匹配','BROAD':'广泛匹配','-':'自动广告(紧密/宽泛/同类/关联)'}
ad['匹配类型中文']=ad['匹配类型'].map(mt).fillna(ad['匹配类型'])
def ad_line(p):
    s=str(p)
    if '高硼硅' in s: return '高硼硅梅森罐'
    if '果茶' in s: return '梅森罐-果茶款'
    if '滤棒' in s: return '梅森罐-滤棒款'
    if '32oz' in s: return '梅森罐-32oz'
    if '梅森' in s: return '梅森罐-64oz/其他'
    if '母乳' in s: return '母乳罐'
    if '水升' in s: return '水升/饮品壶'
    if '饮品罐' in s: return '饮品罐'
    if '洗衣' in s: return '洗衣罐'
    if '糖罐' in s: return '糖罐'
    return '其他产品线(备餐碗/储物/密封/保鲜/扫流等)'
ad['产品线']=ad['广告组合名称'].apply(ad_line)

# ============ 3. 汇总表 ============
# 3.1 市场口径按 query 去重（同一 query 在多个 ASIN 文件里市场总量一致）
mkt=sqp.drop_duplicates('q').set_index('q')
mkt_tot=dict(vol=mkt['vol'].sum(), impr=mkt['m_impr'].sum(), clk=mkt['m_clk'].sum(), add=mkt['m_add'].sum(), ord=mkt['m_ord'].sum())
own_tot=dict(impr=sqp['o_impr'].sum(), clk=sqp['o_clk'].sum(), add=sqp['o_add'].sum(), ord=sqp['o_ord'].sum())
n_q=sqp['q'].nunique(); n_asin=sqp['ASIN'].nunique()

# 3.2 每 ASIN 汇总
def agg_asin(g):
    m=g.drop_duplicates('q')
    return pd.Series({
        '收录搜索词数':len(g),
        '是否Top100截断':'是' if len(g)>=100 else '否',
        '头号搜索词(排名1)':g.loc[g['score'].idxmin(),'搜索查询'],
        '市场搜索查询量(覆盖词)':m['vol'].sum(),
        '市场曝光总量':m['m_impr'].sum(),'市场点击总量':m['m_clk'].sum(),'市场加购总量':m['m_add'].sum(),'市场下单总量':m['m_ord'].sum(),
        '自家曝光':g['o_impr'].sum(),'自家点击':g['o_clk'].sum(),'自家加购':g['o_add'].sum(),'自家下单':g['o_ord'].sum()})
asin_sum=sqp.groupby(['ASIN','品名','颜色','规格','产品线']).apply(agg_asin, include_groups=False).reset_index()
asin_sum=asin_sum.sort_values('自家点击',ascending=False).reset_index(drop=True)

# 3.3 广告产品线 / 匹配类型 / 每日
def ad_agg(g):
    impr=g['展示量'].sum(); clk=g['点击量'].sum(); spend=g['花费'].sum(); sales=g['7天总销售额'].sum()
    odr=g['7天总订单数(#)'].sum(); units=g['7天总销售量(#)'].sum()
    return pd.Series({'展示量':impr,'点击量':clk,'CTR':clk/impr if impr else np.nan,'CPC':spend/clk if clk else np.nan,
        '花费':spend,'7天销售额':sales,'订单数':odr,'销售量':units,
        '转化率CVR':odr/clk if clk else np.nan,'ACOS':spend/sales if sales else np.nan,'ROAS':sales/spend if spend else np.nan})
port_sum=ad.groupby(['广告组合名称','产品线']).apply(ad_agg, include_groups=False).reset_index().sort_values('花费',ascending=False).reset_index(drop=True)
match_sum=ad.groupby('匹配类型中文').apply(ad_agg, include_groups=False).reset_index()
daily=ad.groupby('开始日期').apply(ad_agg, include_groups=False).reset_index().sort_values('开始日期')

# 3.4 搜索词交叉（品牌级）
bs=sqp.groupby('q').agg(sqp_impr=('o_impr','sum'),sqp_clk=('o_clk','sum'),sqp_add=('o_add','sum'),sqp_ord=('o_ord','sum'),
    vol=('vol','max'), n_asins=('ASIN','nunique')).reset_index()
ba=ad.groupby('q').agg(ad_impr=('展示量','sum'),ad_clk=('点击量','sum'),ad_spend=('花费','sum'),ad_sales=('7天总销售额','sum'),
    ad_ord=('7天总订单数(#)','sum'),ad_units=('7天总销售量(#)','sum')).reset_index()
cross=bs.merge(ba,on='q',how='outer').fillna({'sqp_impr':0,'sqp_clk':0,'sqp_add':0,'sqp_ord':0,'ad_impr':0,'ad_clk':0,'ad_spend':0,'ad_sales':0,'ad_ord':0,'ad_units':0,'vol':0,'n_asins':0})
def status(r):
    if r.sqp_clk>0 and r.ad_clk>0: return '双方都有'
    if r.sqp_clk>0 and r.ad_clk==0: return '仅SQP有(自然为主/未投广告)'
    return '仅广告有(长尾词,SQP未收录)'
cross['匹配状态']=cross.apply(status,axis=1)
cross=cross.rename(columns={'q':'搜索词(归一化)'})
# 保留：全部双方+仅SQP + 仅广告中点击>=5
adonly=cross[(cross['匹配状态']=='仅广告有(长尾词,SQP未收录)')]
keep_adonly=adonly[adonly['ad_clk']>=5]
cross_keep=pd.concat([cross[cross['匹配状态']!='仅广告有(长尾词,SQP未收录)'],keep_adonly],ignore_index=True)
cross_keep=cross_keep.sort_values(['sqp_clk','ad_clk'],ascending=False).reset_index(drop=True)
print('cross rows kept:',len(cross_keep),' of',len(cross),'; ad-only kept %d, excluded %d (clicks %.0f)'%(
    len(keep_adonly),len(adonly)-len(keep_adonly),adonly[~adonly.index.isin(keep_adonly.index)]['ad_clk'].sum()))

# 覆盖统计（两套口径：集合口径=词是否在报告中出现；点击桶口径=能否与SQP自家点击对齐）
S=set(bs['q']); A=set(ba['q'])
qc='搜索词(归一化)'
inter_set=cross[cross[qc].isin(S&A)]
sqponly_set=cross[cross[qc].isin(S-A)]
adonly_set=cross[cross[qc].isin(A-S)]
inter=cross[(cross['匹配状态']=='双方都有')]
sqponly=cross[cross['匹配状态']=='仅SQP有(自然为主/未投广告)']
adonlyall=cross[cross['匹配状态']=='仅广告有(长尾词,SQP未收录)']
# 点击桶42083的拆解：完全不在SQP / 在SQP但自家0点击
adonly_absent=adonlyall[~adonlyall[qc].isin(S)]
adonly_inzero=adonlyall[adonlyall[qc].isin(S)]
cov={
 'sqp_terms':n_q,'ad_terms':ad['q'].nunique(),
 'interset_n':len(inter_set),'sqponlyset_n':len(sqponly_set),'adonlyset_n':len(adonly_set),'union_n':len(S|A),
 'inter_n':len(inter),'sqponly_n':len(sqponly),'adonly_n':len(adonlyall),
 'adonly_absent_n':len(adonly_absent),'adonly_inzero_n':len(adonly_inzero),
 'sqp_clk_total':own_tot['clk'],'sqp_ord_total':own_tot['ord'],
 'interset_sqp_clk':inter_set['sqp_clk'].sum(),'interset_ad_clk':inter_set['ad_clk'].sum(),'interset_ad_ord':inter_set['ad_ord'].sum(),
 'interset_ad_spend':inter_set['ad_spend'].sum(),'interset_ad_sales':inter_set['ad_sales'].sum(),
 'sqponlyset_sqp_clk':sqponly_set['sqp_clk'].sum(),
 'adonlyset_ad_clk':adonly_set['ad_clk'].sum(),'adonlyset_ad_ord':adonly_set['ad_ord'].sum(),
 'adonlyset_ad_spend':adonly_set['ad_spend'].sum(),'adonlyset_ad_sales':adonly_set['ad_sales'].sum(),
 'inter_sqp_clk':inter['sqp_clk'].sum(),'inter_sqp_ord':inter['sqp_ord'].sum(),
 'sqponly_sqp_clk':sqponly['sqp_clk'].sum(),'sqponly_sqp_ord':sqponly['sqp_ord'].sum(),
 'ad_clk_total':ad['点击量'].sum(),'ad_ord_total':ad['7天总订单数(#)'].sum(),'ad_spend_total':ad['花费'].sum(),'ad_sales_total':ad['7天总销售额'].sum(),
 'inter_ad_clk':inter['ad_clk'].sum(),'inter_ad_ord':inter['ad_ord'].sum(),'inter_ad_spend':inter['ad_spend'].sum(),'inter_ad_sales':inter['ad_sales'].sum(),
 'adonly_ad_clk':adonlyall['ad_clk'].sum(),'adonly_ad_ord':adonlyall['ad_ord'].sum(),'adonly_ad_spend':adonlyall['ad_spend'].sum(),'adonly_ad_sales':adonlyall['ad_sales'].sum()}
for k,v in cov.items(): print(k, round(v,2) if isinstance(v,float) else v)

# 保存中间对象
import pickle
pickle.dump(dict(sqp=sqp,ad=ad,asin_sum=asin_sum,port_sum=port_sum,match_sum=match_sum,daily=daily,
                 cross_keep=cross_keep,mkt_tot=mkt_tot,own_tot=own_tot,cov=cov,n_q=n_q,n_asin=n_asin,
                 mkt=mkt), open(r'C:\Users\adm\Desktop\gaoxiaocheng\_prep.pkl','wb'))
print('PREP DONE')
