# -*- coding: utf-8 -*-
import pandas as pd, glob, os
base=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'; cd=base+r'\产品9月份搜索查询绩效'
f=cd+r'\B0DGCVK1JL.csv'
d=pd.read_csv(f, skiprows=1)
s=pd.to_numeric(d['搜索查询得分'])
print('rows',len(s),'min',s.min(),'max',s.max(),'mean',s.mean(),'nunique',s.nunique())
print('sorted scores:', sorted(s.tolist())[:20],'...',sorted(s.tolist())[-10])
print('is exactly 1..100 each once?', sorted(s.tolist())==list(range(1,101)))
# a non-truncated file
f2=cd+r'\B0FSRPXLSV.csv'
d2=pd.read_csv(f2, skiprows=1)
s2=pd.to_numeric(d2['搜索查询得分'])
print('small file scores:', s2.tolist())
# check a 68-row file
f3=cd+r'\B0DWRNKF58.csv'
d3=pd.read_csv(f3, skiprows=1)
s3=pd.to_numeric(d3['搜索查询得分'])
print('68-row: rows',len(s3),'mean',s3.mean(),'min',s3.min(),'max',s3.max())
print('sorted:', sorted(s3.tolist()))
