# -*- coding: utf-8 -*-
from openpyxl import load_workbook
wb = load_workbook(r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx', data_only=False)
ws = wb['04_SQP_ASIN汇总']
# header + first 6 data rows, selected columns
rows = list(ws.iter_rows(min_row=2, max_row=8, min_col=1, max_col=23, values_only=True))
hdr = rows[0]
sel = [0,1,2,3,4,5,6,7,8,9,10,13,14,17]
print(' | '.join(str(hdr[i]) for i in sel))
for r in rows[1:]:
    print(' | '.join('' if r[i] is None else str(r[i]) for i in sel))
# product line counts
from collections import Counter
lines = Counter()
for r in ws.iter_rows(min_row=3, max_row=53, min_col=5, max_col=5, values_only=True):
    lines[r[0]] += 1
print('--- 产品线分布 ---')
for k,v in lines.most_common():
    print(k, v)
