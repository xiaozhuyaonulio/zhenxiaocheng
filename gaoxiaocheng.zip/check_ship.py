# -*- coding: utf-8 -*-
import pandas as pd
p=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效\B0CN4MVL5L.csv'
df=pd.read_csv(p, skiprows=1); df.columns=[c.strip() for c in df.columns]
cols=list(df.columns)
def find(stage, day):
    for c in cols:
        if day in c and ('当日' in c or '1 天' in c or '2天' in c):
            if stage in c: return c
    return None
stages={'点击':'点击量','加购':'购物车添加','下单':'下单'}
# 直接列出所有配送列名
print('配送相关列:')
for c in cols:
    if '配送' in c: print(' -',repr(c))
q='pyrex canisters with lids'
r=df[df['搜索查询'].str.strip().str.lower()==q].iloc[0]
print('\npyrex行配送数字:')
for c in cols:
    if '配送' in c: print(c,'=',r[c])

def cols_of(prefix_keys):
    out=[]
    for c in cols:
        if '配送' in c and all(k in c for k in prefix_keys): out.append(c)
    return out
click_tot='点击量：总次数'; add_tot='购物车添加：总数'; ord_tot='购买：下单总数'
click_b=[c for c in cols if c.startswith('点击') and '配送' in c]
add_b=[c for c in cols if ('购物车添加' in c or '加入购物车' in c) and '配送' in c]
ord_b=[c for c in cols if ('下单' in c) and '配送' in c]
print('\n点击配送列:',click_b)
print('加购配送列:',add_b)
print('下单配送列:',ord_b)
for name,tot,buckets in [('点击',click_tot,click_b),('加购',add_tot,add_b),('下单',ord_tot,ord_b)]:
    d=df[df[tot]>0]
    s=d[buckets].fillna(0).sum(axis=1)
    gap=d[tot]-s
    print('%s环节: 有数据行%d, 齐平%d, 有缺口%d, 缺口分布%s'%(name,len(d),(gap==0).sum(),(gap>0).sum(),gap.value_counts().sort_index().to_dict()))
