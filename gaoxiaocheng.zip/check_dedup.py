# -*- coding: utf-8 -*-
import pandas as pd, glob, os
base=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'; cd=base+r'\产品9月份搜索查询绩效'
frames=[]
for f in glob.glob(cd+r'\*.csv'):
    d=pd.read_csv(f, skiprows=1, dtype=str); d['ASIN']=os.path.basename(f)[:-4]; frames.append(d)
sqp=pd.concat(frames,ignore_index=True)
import re
def norm(s): return re.sub(r'\s+',' ',str(s).strip().lower())
sqp['q']=sqp['搜索查询'].apply(norm)
for c in ['曝光：曝光总量','点击量：总次数','购物车添加：总数','购买：下单总数']:
    sqp[c]=pd.to_numeric(sqp[c],errors='coerce')
dup=sqp.groupby('q').agg(n=('ASIN','nunique'),
    imin=('曝光：曝光总量','min'),imax=('曝光：曝光总量','max'),
    cmin=('点击量：总次数','min'),cmax=('点击量：总次数','max'),
    amin=('购物车添加：总数','min'),amax=('购物车添加：总数','max'),
    omin=('购买：下单总数','min'),omax=('购买：下单总数','max'))
multi=dup[dup.n>1]
print('queries appearing in >1 ASIN files:', len(multi), 'of', len(dup))
for lo,hi,name in [('imin','imax','impr'),('cmin','cmax','clk'),('amin','amax','add'),('omin','omax','ord')]:
    mism=(multi[lo]!=multi[hi]).sum()
    print(name,'rows with differing market totals across ASIN files:',mism)
