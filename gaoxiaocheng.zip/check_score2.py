# -*- coding: utf-8 -*-
import pandas as pd, glob, os
cd=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效'
d=pd.read_csv(cd+r'\B0DGCVK1JL.csv', skiprows=1)
d['score']=pd.to_numeric(d['搜索查询得分']); d['vol']=pd.to_numeric(d['搜索查询量'])
d['oclk']=pd.to_numeric(d['点击量：ASIN 数量']); d['oord']=pd.to_numeric(d['下单成交：ASIN 数量'])
print('corr score vs vol:', d['score'].corr(d['vol']))
print('corr score vs own clicks:', d['score'].corr(d['oclk']))
print('corr score vs own orders:', d['score'].corr(d['oord']))
print('top5 by score:')
print(d.sort_values('score').head(5)[['搜索查询','score','vol','oclk','oord']].to_string(index=False))
print('top5 by vol:')
print(d.sort_values('vol',ascending=False).head(5)[['搜索查询','score','vol','oclk','oord']].to_string(index=False))
# check rank correlation across all files: is score always 1..N with 1=highest vol?
import re
bad=0; tot=0
for f in glob.glob(cd+r'\*.csv'):
    x=pd.read_csv(f, skiprows=1)
    x['score']=pd.to_numeric(x['搜索查询得分']); x['vol']=pd.to_numeric(x['搜索查询量'])
    tot+=1
    srt=x.sort_values('score')
    if not (srt['score'].tolist()==list(range(1,len(x)+1))): bad+=1
print('files where score != 1..N:',bad,'/',tot)
# is vol monotonically decreasing with score? count inversions fraction
x=d.sort_values('score')
v=x['vol'].tolist()
inv=sum(1 for i in range(len(v)-1) for j in range(i+1,len(v)) if v[j]>v[i])
print('vol inversions vs score rank:', inv, 'of', len(v)*(len(v)-1)/2)
