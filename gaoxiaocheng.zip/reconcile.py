# -*- coding: utf-8 -*-
import pandas as pd, glob, os, re, pickle
base=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
def norm(s): return re.sub(r'\s+',' ',str(s).strip().lower())

# SQP
fr=[]
for f in glob.glob(base+r'\产品9月份搜索查询绩效\*.csv'):
    d=pd.read_csv(f,skiprows=1,dtype=str); d['ASIN']=os.path.basename(f)[:-4]; fr.append(d)
sqp=pd.concat(fr,ignore_index=True)
for c in ['曝光量：ASIN 计数','点击量：ASIN 数量','加购：ASIN 数量','下单成交：ASIN 数量','搜索查询量']:
    sqp[c]=pd.to_numeric(sqp[c],errors='coerce')
sqp['q']=sqp['搜索查询'].apply(norm)

# 广告
ad=pd.read_excel(base+r'\26.9.xlsx')
ad['q']=ad['客户搜索词'].dropna().apply(norm)
ad['点击量']=pd.to_numeric(ad['点击量'],errors='coerce')
ad['7天总订单数(#)']=pd.to_numeric(ad['7天总订单数(#)'],errors='coerce')
ad['花费']=pd.to_numeric(ad['花费'],errors='coerce')
ad['7天总销售额']=pd.to_numeric(ad['7天总销售额'],errors='coerce')

print('=== 词数（原始 vs 归一化）===')
print('SQP 原始字符串不重复词:', sqp['搜索查询'].nunique())
print('SQP 归一化后不重复词:', sqp['q'].nunique())
print('广告 原始字符串不重复词:', ad['客户搜索词'].nunique())
print('广告 归一化后不重复词:', ad['q'].nunique())

S=set(sqp['q']); A=set(ad['q'])
print('\n=== 纯集合勾稽（不管有没有点击）===')
print('交集（两边都出现）:', len(S&A))
print('仅SQP出现:', len(S-A))
print('仅广告出现:', len(A-S))
print('校验: 广告总数 = 交集+仅广告 =', len(S&A)+len(A-S))
print('校验: SQP总数 = 交集+仅SQP =', len(S&A)+len(S-A))

# 品牌级自家点击
bs=sqp.groupby('q').agg(clk=('点击量：ASIN 数量','sum')).reset_index()
ba=ad.groupby('q').agg(aclk=('点击量','sum'),aspend=('花费','sum'),asales=('7天总销售额','sum'),aord=('7天总订单数(#)','sum')).reset_index()
cr=bs.merge(ba,on='q',how='outer').fillna(0)
both=cr[(cr.clk>0)&(cr.aclk>0)]
sqpo=cr[(cr.clk>0)&(cr.aclk==0)]
ado=cr[cr.clk==0]
print('\n=== 按“有无点击”分类（工作簿03表口径）===')
print('双方都有点击:', len(both))
print('仅SQP有点击(广告0点击):', len(sqpo))
print('SQP自家0点击的词(含广告有点击):', len(ado))
print('  其中: 词在SQP文件里出现过但自家0点击:', len(set(ado.q)&S))
print('  其中: 词根本不在SQP里:', len(set(ado.q)-S))
print('  其中: 广告也0点击的:', (ado.aclk==0).sum())
print('三类合计 =', len(both)+len(sqpo)+len(ado), ' 应等于并集', len(S|A))
print('\n广告独有(SQP0点击)词的广告点击占比: %.1f%%'%(ado[ado.aclk>0]['aclk'].sum()/ad['点击量'].sum()*100))
print('广告独有词数(广告有点击的):', (ado.aclk>0).sum())
pkl=pickle.load(open(r'C:\Users\adm\Desktop\gaoxiaocheng\_prep.pkl','rb'))
print('\npkl里cov记录:', {k:pkl['cov'][k] for k in ('sqp_terms','ad_terms','inter_n','sqponly_n','adonly_n')})
