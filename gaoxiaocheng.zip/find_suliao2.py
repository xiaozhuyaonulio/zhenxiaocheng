# -*- coding: utf-8 -*-
import pandas as pd
base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
xl = pd.ExcelFile(base + r'\26.9.xlsx')
print('26.9 sheets:', xl.sheet_names)
for sn in xl.sheet_names:
    d = pd.read_excel(xl, sheet_name=sn)
    for c in d.columns:
        s = d[c].dropna().astype(str)
        h = s[s.str.contains('塑料')]
        if len(h):
            print('sheet[%s] col[%s]:' % (sn, c), sorted(set(h))[:10])

xl2 = pd.ExcelFile(base + r'\对应关系.xlsx')
print('对应关系 sheets:', xl2.sheet_names)
for sn in xl2.sheet_names:
    d = pd.read_excel(xl2, sheet_name=sn)
    for c in d.columns:
        s = d[c].dropna().astype(str)
        h = s[s.str.contains('塑料')]
        if len(h):
            print('对应关系 sheet[%s] col[%s]:' % (sn, c), sorted(set(h))[:10])
print('done')
