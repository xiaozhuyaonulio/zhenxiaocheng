# -*- coding: utf-8 -*-
from openpyxl import load_workbook
wb = load_workbook(r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx', data_only=False)
ws = wb['03_数据总览']
for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=5):
    vals = [c.value for c in row]
    if any(v not in (None, '') for v in vals):
        print(row[0].row, '|', ' || '.join('' if v is None else str(v) for v in vals))
