# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, os, re, glob
pd.set_option('display.max_columns', None); pd.set_option('display.width', 320); pd.set_option('display.max_colwidth', 60)
base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
csv_dir = base + r'\产品9月份搜索查询绩效'

# load SQP
frames=[]
for f in glob.glob(csv_dir+r'\\*.csv'):
    d=pd.read_csv(f, skiprows=1, dtype=str)
    d['ASIN']=os.path.basename(f)[:-4]
    frames.append(d)
sqp=pd.concat(frames, ignore_index=True)
mp=pd.read_excel(base+r'\对应关系.xlsx').dropna(subset=['ASIN'])
own_asins=set(mp['ASIN'].astype(str).str.strip())
csv_asins=set(sqp['ASIN'].unique())

ad=pd.read_excel(base+r'\26.9.xlsx')

# ---- campaign naming structure ----
print('=== 广告组合名称(portfolio) unique (%d) ==='%ad['广告组合名称'].nunique())
for x in sorted(ad['广告组合名称'].dropna().unique()): print('  ', x)
print()
# does adgroup contain an OWN asin?
def find_own(t):
    ms=re.findall(r'B0[A-Z0-9]{8}', str(t))
    hit=[m for m in ms if m in own_asins]
    return hit[0] if hit else None
ad['own_asin']=(ad['广告活动名称'].fillna('')+' '+ad['广告组名称'].fillna('')).apply(find_own)
for c in ['展示量','点击量','花费','7天总销售额','7天总订单数(#)']:
    ad[c]=pd.to_numeric(ad[c],errors='coerce').fillna(0)
cov=ad.groupby(ad['own_asin'].notna())[['展示量','点击量','花费','7天总销售额','7天总订单数(#)']].sum()
cov['rows']=ad.groupby(ad['own_asin'].notna()).size()
print('=== ad rows attributable to an OWN asin parsed from campaign/adgroup name ===')
print(cov.to_string())
print()
# portfolios not matching any own asin - sample campaign names
un=ad[ad['own_asin'].isna()]
print('unattributed spend by portfolio:')
print(un.groupby('广告组合名称')['花费'].sum().sort_values(ascending=False).head(25).to_string())
print()

# ---- term overlap (brand level) ----
def norm(s):
    return re.sub(r'\s+',' ', str(s).strip().lower())
sqp_terms=set(sqp['搜索查询'].apply(norm))
ad_terms=set(ad['客户搜索词'].dropna().apply(norm))
print('=== TERM OVERLAP (brand level) ===')
print('SQP unique queries:', len(sqp_terms), ' AD unique terms:', len(ad_terms))
inter=sqp_terms & ad_terms
print('intersection:', len(inter), ' = %.1f%% of SQP terms'%(100*len(inter)/len(sqp_terms)))
# ad spend/clicks on overlapping terms
ad['nterm']=ad['客户搜索词'].dropna().apply(norm)
ov=ad[ad['nterm'].isin(sqp_terms)]
print('ad rows on SQP-overlapping terms:', len(ov), '/', len(ad))
for c in ['展示量','点击量','花费','7天总销售额','7天总订单数(#)']:
    print('  ', c, round(ov[c].sum(),2), ' share of ad total %.1f%%'%(100*ov[c].sum()/ad[c].sum()))
print()

# ---- funnel semantics verification on SQP ----
q=sqp.copy()
for c in ['搜索查询量','曝光：曝光总量','点击量：总次数','购物车添加：总数','购买：下单总数',
          '点击量：点击率 %','加入购物车：加购率%','下单成交：成交转化率%',
          '曝光量：ASIN 计数','曝光：ASIN 曝光占比 %','点击量：ASIN 数量','点击量：ASIN 份额 %',
          '加购：ASIN 数量','加入购物车：ASIN 加购占比 %','下单成交：ASIN 数量','下单: ASIN 占比 %','搜索查询得分']:
    q[c]=pd.to_numeric(q[c],errors='coerce')
print('=== funnel rate check (market level, rate vs /搜索查询量) ===')
print('CTR:  clicks/query  match reported? corr=', np.corrcoef(q['点击量：总次数']/q['搜索查询量'], q['点击量：点击率 %']/100)[0,1])
print('ADDR: adds/query    match reported? corr=', np.corrcoef(q['购物车添加：总数']/q['搜索查询量'], q['加入购物车：加购率%']/100)[0,1])
print('CVR:  orders/query  match reported? corr=', np.corrcoef(q['购买：下单总数']/q['搜索查询量'], q['下单成交：成交转化率%']/100)[0,1])
print('ASIN impr share = asin_impr/total? corr=', np.corrcoef(q['曝光量：ASIN 计数']/q['曝光：曝光总量'], q['曝光：ASIN 曝光占比 %']/100)[0,1])
print('ASIN click share = asin_clk/total? corr=', np.corrcoef(q['点击量：ASIN 数量']/q['点击量：总次数'], q['点击量：ASIN 份额 %']/100)[0,1])
print('ASIN order share = asin_ord/total? corr=', np.corrcoef(q['下单成交：ASIN 数量']/q['购买：下单总数'].replace(0,np.nan), q['下单: ASIN 占比 %']/100)[0,1])
print('score describe:'); print(q['搜索查询得分'].describe().to_string())
print('score range:', q['搜索查询得分'].min(), '-', q['搜索查询得分'].max())
# zero/ suppression patterns
print('rows where asin clicks=0:', (q['点击量：ASIN 数量']==0).sum(), '/', len(q))
print('rows where asin orders=0:', (q['下单成交：ASIN 数量']==0).sum(), '/', len(q))
print('min positive market impressions:', q.loc[q['曝光：曝光总量']>0,'曝光：曝光总量'].min())
