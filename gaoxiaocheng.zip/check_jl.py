# -*- coding: utf-8 -*-
import pandas as pd
f = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效\B0DGCVK1JL.csv'
d = pd.read_csv(f, skiprows=1, dtype=str)
d['score'] = pd.to_numeric(d['搜索查询得分'])
d['vol'] = pd.to_numeric(d['搜索查询量'])
d['oclk'] = pd.to_numeric(d['点击量：ASIN 数量'])
print('行数(收录词数):', len(d))
print('全部100个词的搜索查询量合计 =', int(d['vol'].sum()))
print('---- 得分前8的词（CSV原始排序）----')
for _, r in d.sort_values('score').head(8).iterrows():
    print(int(r['score']), '|', r['搜索查询'], '| 该词搜索量', int(r['vol']), '| 自家点击', int(r['oclk']))
print('---- 该文件里搜索量最大的5个词 ----')
for _, r in d.sort_values('vol', ascending=False).head(5).iterrows():
    print(int(r['score']), '|', r['搜索查询'], '| 搜索量', int(r['vol']))
