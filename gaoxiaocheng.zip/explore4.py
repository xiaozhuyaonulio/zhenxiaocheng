# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, os, re, glob
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 300)
pd.set_option('display.max_colwidth', 50)

base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
csv_dir = base + r'\产品9月份搜索查询绩效'

# ---------- 1. load all SQP csvs ----------
csv_files = glob.glob(csv_dir + r'\*.csv')
print('CSV files:', len(csv_files))
frames = []
hdr = None
for f in csv_files:
    asin = os.path.basename(f).replace('.csv','')
    # first line is filter metadata; header on line 2
    df = pd.read_csv(f, skiprows=1, dtype=str)
    df['__ASIN_FILE'] = asin
    if hdr is None: hdr = list(df.columns)
    frames.append(df)
sqp = pd.concat(frames, ignore_index=True)
print('SQP combined rows:', len(sqp))
print('SQP columns (%d):' % len(hdr))
for c in hdr: print('   ', c)
print('报告日期 unique:', sqp['报告日期'].dropna().unique()[:5])
print('rows per file, describe:')
print(sqp.groupby('__ASIN_FILE').size().describe().to_string())
# obfuscation check: numeric columns that contain non numeric
num_cols = [c for c in sqp.columns if c not in ('搜索查询','报告日期','__ASIN_FILE')]
bad = {}
for c in num_cols:
    v = sqp[c].dropna()
    nonnum = v[~v.str.replace('.','',regex=False).str.replace('-','',regex=False).str.isdigit()]
    # detect ranges like "1-10"
    rng = v[v.str.contains('-', na=False) & v.str.replace('-','',regex=False).str.isdigit()]
    if len(rng): bad[c] = ('range', rng.unique()[:5].tolist())
    else:
        other = v[~v.apply(lambda x: re.fullmatch(r'\d*\.?\d+', x) is not None)]
        if len(other): bad[c] = ('other', other.unique()[:5].tolist())
print('obfuscation/non-numeric findings:', bad if bad else 'NONE - all numeric')
print()

# ---------- 2. mapping ----------
mp = pd.read_excel(base + r'\对应关系.xlsx').dropna(how='all')
mp = mp.dropna(subset=['ASIN'])
map_asins = set(mp['ASIN'].astype(str).str.strip())
csv_asins = set(os.path.basename(f).replace('.csv','') for f in csv_files)
print('mapping ASINs:', len(map_asins), ' CSV ASINs:', len(csv_asins))
print('in mapping but NO csv:', sorted(map_asins - csv_asins))
print('csv but NOT in mapping:', sorted(csv_asins - map_asins))
print()

# ---------- 3. ad report ----------
ad = pd.read_excel(base + r'\26.9.xlsx')
print('AD rows:', len(ad))
print('AD date range:', ad['开始日期'].min(), '->', ad['结束日期'].max())
print('unique 客户搜索词:', ad['客户搜索词'].nunique())
print('unique 广告活动:', ad['广告活动名称'].nunique(), ' unique 广告组:', ad['广告组名称'].nunique())
print('匹配类型:', ad['匹配类型'].value_counts(dropna=False).to_dict())
print('投放 sample:', ad['投放'].dropna().unique()[:10])
# extract ASIN-like tokens from campaign/ad group
text = (ad['广告活动名称'].fillna('')+' '+ad['广告组名称'].fillna('')+' '+ad['广告组合名称'].fillna(''))
asins_in_ad = set()
for t in text.unique():
    for m in re.findall(r'B0[A-Z0-9]{8}', str(t)):
        asins_in_ad.add(m)
print('ASIN-like tokens found in ad names:', len(asins_in_ad))
print('ad-name ASINs covered by csv:', len(asins_in_ad & csv_asins), '/', len(asins_in_ad))
print('ad-name ASINs NOT in csv:', sorted(asins_in_ad - csv_asins)[:30])
print()
# numeric totals
for c in ['展示量','点击量','花费','7天总销售额','7天总订单数(#)','7天总销售量(#)']:
    print('AD total', c, '=', pd.to_numeric(ad[c], errors='coerce').sum())
