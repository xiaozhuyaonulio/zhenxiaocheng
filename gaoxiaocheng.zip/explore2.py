# -*- coding: utf-8 -*-
import pandas as pd
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 250)
pd.set_option('display.max_colwidth', 30)

base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'

# 1. 对应关系
mp = pd.read_excel(base + r'\对应关系.xlsx', sheet_name='Sheet1')
print('=== 对应关系.xlsx ===')
print('shape:', mp.shape)
print('columns:', list(mp.columns))
print(mp.head(20).to_string())
print()

# 2. 26.9.xlsx header + sample
xl = pd.ExcelFile(base + r'\26.9.xlsx')
print('=== 26.9.xlsx sheets:', xl.sheet_names)
df = pd.read_excel(base + r'\26.9.xlsx', sheet_name=xl.sheet_names[0], nrows=5)
print('columns:', list(df.columns))
print(df.head(5).to_string())
