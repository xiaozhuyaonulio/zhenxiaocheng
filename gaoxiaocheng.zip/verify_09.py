# -*- coding: utf-8 -*-
from openpyxl import load_workbook
p=r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx'
wb=load_workbook(p)
ws1=wb['01_说明与结论']
for row in range(1, ws1.max_row+1):
    if ws1.cell(row,1).value=='02_名词解释':
        print('NAV:', ws1.cell(row,2).value)
ws9=wb['09_口径差异与脱敏']
for row in range(1, ws9.max_row+1):
    a=ws9.cell(row,1).value
    if a in ('归因口径','“率”的分母'):
        print('09[%s]:'%a, str(ws9.cell(row,2).value)[:80])
