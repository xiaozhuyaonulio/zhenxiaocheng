# -*- coding: utf-8 -*-
import pandas as pd
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 300)
pd.set_option('display.max_colwidth', 40)
pd.set_option('display.max_rows', 200)

base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
mp = pd.read_excel(base + r'\对应关系.xlsx', sheet_name='Sheet1')
print('shape:', mp.shape)
print('columns:', list(mp.columns))
print(mp.to_string())
