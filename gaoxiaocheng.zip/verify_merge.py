# -*- coding: utf-8 -*-
from openpyxl import load_workbook
p=r'C:\Users\adm\Desktop\gaoxiaocheng\SQP搜索查询绩效_51个ASIN合并总表.xlsx'
wb=load_workbook(p, read_only=True)
print('sheets:', wb.sheetnames)
ws=wb['合并明细(3117行)']
print('dims:', ws.max_row, 'rows x', ws.max_column, 'cols')
hdr=[c.value for c in next(ws.iter_rows(min_row=1,max_row=1))]
print('前6列表头:', hdr[:6])
print('末2列表头:', hdr[-2:])
# 找 pasta jars 那行核对
for row in ws.iter_rows(min_row=2, values_only=True):
    if row[0]=='B0CN4MVL5L' and str(row[1]).strip().lower()=='pasta jars with lids multi size':
        print('pasta行 ASIN/词/搜索量/曝光总量/ASIN计数/占比:', row[0],row[1],row[3],row[4],row[5],row[6])
        break
ws2=wb['不重复搜索词(2410个)']
print('词清单 dims:', ws2.max_row,'x',ws2.max_column)
rows=list(ws2.iter_rows(min_row=1,max_row=4,values_only=True))
for r in rows: print(r)
