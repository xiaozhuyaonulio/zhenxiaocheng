# -*- coding: utf-8 -*-
from openpyxl import load_workbook
p=r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx'
wb=load_workbook(p)
ws=wb['02_名词解释']
print('02 dims:', ws.dimensions, 'maxrow:', ws.max_row)
# print section rows (col A merged bars) and a few term rows
for row in range(1, ws.max_row+1):
    v=ws.cell(row,1).value
    b=ws.cell(row,2).value
    if v and ('A.' in str(v) or 'B.' in str(v) or 'C.' in str(v) or 'D.' in str(v) or 'E.' in str(v) or 'B-' in str(v) or 'A-' in str(v)):
        print('SEC r%d:'%row, v)
# sample rows
for rr in (5,6,24,25,40,41,60,61,75,76):
    print('r%d:'%rr, ws.cell(rr,1).value, '|', ws.cell(rr,2).value, '|', str(ws.cell(rr,3).value)[:40])
print('sheets total:', len(wb.sheetnames))
