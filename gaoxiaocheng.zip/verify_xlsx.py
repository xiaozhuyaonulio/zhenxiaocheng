# -*- coding: utf-8 -*-
from openpyxl import load_workbook
p=r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx'
wb=load_workbook(p)
print('sheets:', wb.sheetnames)
for name in wb.sheetnames:
    ws=wb[name]
    print(f'  {name}: dims={ws.dimensions}, charts={len(ws._charts)}')
# chart details
wc=wb['10_图表']
for ch in wc._charts:
    print('CHART:', ch.title.tx.rich.p[0].r[0].t if ch.title else '?', '| series:', len(ch.series))
# spot formulas
w5=wb['05_SQP_漏斗']
print('funnel C6 formula:', w5['C6'].value, '| G8:', w5['G8'].value, '| B14:', w5['B14'].value)
w4=wb['04_SQP_ASIN汇总']
print('04 R3:', w4['R3'].value, '| total row 54 S54:', w4['S54'].value)
w8=wb['08_搜索词交叉对比']
print('08 N4:', w8['N4'].value, '| R4:', w8['R4'].value, '| maxrow:', w8.max_row)
w6=wb['06_广告_产品线与匹配']
print('06 N5:', w6['N5'].value, '| N25:', w6['N25'].value, '| N29:', w6['N29'].value)
w3=wb['03_数据总览']
print('03 B20:', w3['B20'].value, 'C20:', w3['C20'].value, 'D20:', w3['D20'].value)
# data sanity: first asin row values
print('04 row3 sample:', [w4.cell(3,c).value for c in (1,2,6,15,17)])
# cross first row
print('08 row4 sample:', [w8.cell(4,c).value for c in (1,2,6,10,14,18)])
