# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, os, re, glob
pd.set_option('display.max_columns', None); pd.set_option('display.width', 320); pd.set_option('display.max_colwidth', 60)
base=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'; cd=base+r'\产品9月份搜索查询绩效'
frames=[]
for f in glob.glob(cd+r'\*.csv'):
    d=pd.read_csv(f, skiprows=1, dtype=str); d['ASIN']=os.path.basename(f)[:-4]; frames.append(d)
sqp=pd.concat(frames, ignore_index=True)
mp=pd.read_excel(base+r'\对应关系.xlsx').dropna(subset=['ASIN'])
namemap=dict(zip(mp['ASIN'].astype(str).str.strip(), mp['品名'].astype(str)))
ad=pd.read_excel(base+r'\26.9.xlsx')
for c in ['展示量','点击量','花费','7天总销售额','7天总订单数(#)','7天总销售量(#)']: ad[c]=pd.to_numeric(ad[c],errors='coerce').fillna(0)
for c in ['曝光量：ASIN 计数','点击量：ASIN 数量','加购：ASIN 数量','下单成交：ASIN 数量']:
    sqp[c]=pd.to_numeric(sqp[c],errors='coerce').fillna(0)
sqp['品名']=sqp['ASIN'].map(namemap)

def sqp_line(name):
    s=str(name)
    if '高硼硅' in s: return '梅森罐-高硼硅'
    if '果茶' in s: return '梅森罐-果茶款'
    if '滤棒' in s: return '梅森罐-滤棒款'
    if '梅森罐32' in s: return '梅森罐-32oz'
    if '梅森罐64' in s: return '梅森罐-64oz'
    if '梅森罐' in s: return '梅森罐-其他'
    if '母乳罐' in s: return '母乳罐'
    if '水升' in s: return '水升'
    if '饮品罐' in s: return '饮品罐'
    if '洗衣罐' in s: return '洗衣罐'
    if '糖罐' in s: return '糖罐'
    if '圆形' in s or '方形' in s: return '保鲜/储物套装'
    return '其他'
sqp['line']=sqp['品名'].apply(sqp_line)

def ad_line(p):
    s=str(p)
    if '高硼硅' in s: return '梅森罐-高硼硅'
    if '果茶' in s: return '梅森罐-果茶款'
    if '滤棒' in s: return '梅森罐-滤棒款'
    if '32oz' in s: return '梅森罐-32oz'
    if '灰色梅森' in s or '梅森罐' in s: return '梅森罐-64oz/其他'
    if '母乳' in s: return '母乳罐'
    if '水升' in s: return '水升'
    if '饮品罐' in s: return '饮品罐'
    if '洗衣' in s: return '洗衣罐'
    if '糖罐' in s: return '糖罐'
    return '（广告独有产品线：备餐碗/储物/密封/保鲜/扫流等）'
ad['line']=ad['广告组合名称'].apply(ad_line)

g1=sqp.groupby('line').agg(sqp_impr=('曝光量：ASIN 计数','sum'),sqp_clk=('点击量：ASIN 数量','sum'),
                           sqp_add=('加购：ASIN 数量','sum'),sqp_ord=('下单成交：ASIN 数量','sum'),
                           n_asins=('ASIN','nunique')).reset_index()
g2=ad.groupby('line').agg(ad_impr=('展示量','sum'),ad_clk=('点击量','sum'),ad_spend=('花费','sum'),
                          ad_sales=('7天总销售额','sum'),ad_ord=('7天总订单数(#)','sum')).reset_index()
print('=== SQP by product line ==='); print(g1.to_string(index=False)); print()
print('=== AD by portfolio-line ==='); print(g2.to_string(index=False)); print()
# mason aggregate comparison
mason_sqp=g1[g1.line.str.contains('梅森罐')][['sqp_impr','sqp_clk','sqp_add','sqp_ord']].sum()
mason_ad =g2[g2.line.str.contains('梅森罐')][['ad_impr','ad_clk','ad_spend','ad_sales','ad_ord']].sum()
print('MASON ONLY: SQP own impr/clk/ord = %.0f/%.0f/%.0f'%(mason_sqp.sqp_impr,mason_sqp.sqp_clk,mason_sqp.sqp_ord))
print('MASON ONLY: AD      impr/clk/ord = %.0f/%.0f/%.0f (spend %.0f sales %.0f)'%(mason_ad.ad_impr,mason_ad.ad_clk,mason_ad.ad_ord,mason_ad.ad_spend,mason_ad.ad_sales))
print('ad/sqp impr %.0f%%  clk %.0f%%  ord %.0f%%'%(100*mason_ad.ad_impr/mason_sqp.sqp_impr,100*mason_ad.ad_clk/mason_sqp.sqp_clk,100*mason_ad.ad_ord/mason_sqp.sqp_ord))
print()
# ad-only lines share of totals
only=g2[g2.line.str.contains('广告独有')]
print('AD-ONLY lines (no SQP files): impr %.0f clk %.0f spend %.0f sales %.0f ord %.0f'%(
  only.ad_impr.sum(),only.ad_clk.sum(),only.ad_spend.sum(),only.ad_sales.sum(),only.ad_ord.sum()))
print('as %% of ALL ad: impr %.1f%% clk %.1f%% spend %.1f%% sales %.1f%% ord %.1f%%'%(
  100*only.ad_impr.sum()/ad['展示量'].sum(),100*only.ad_clk.sum()/ad['点击量'].sum(),
  100*only.ad_spend.sum()/ad['花费'].sum(),100*only.ad_sales.sum()/ad['7天总销售额'].sum(),100*only.ad_ord.sum()/ad['7天总订单数(#)'].sum()))
