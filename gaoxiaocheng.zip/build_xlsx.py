# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, pickle, unicodedata
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference

P=pickle.load(open(r'C:\Users\adm\Desktop\gaoxiaocheng\_prep.pkl','rb'))
sqp,ad=P['sqp'],P['ad']
asin_sum,port_sum,match_sum,daily=P['asin_sum'],P['port_sum'],P['match_sum'],P['daily']
cross_keep=P['cross_keep']; mkt_tot,own_tot,cov=P['mkt_tot'],P['own_tot'],P['cov']
out=r'C:\Users\adm\Desktop\gaoxiaocheng\9月搜索数据整体分析.xlsx'

DARK='17365D'; MID='2E5E9C'; LIGHT='DCE6F1'; LIGHT2='F2F6FB'; GREY='808080'; WARN='C0504D'; GOOD='4F8A4F'
FONT='微软雅黑'
thin=Side(style='thin',color='B8C7D9')
border=Border(left=thin,right=thin,top=thin,bottom=thin)
INT='#,##0'; MONEY='"$"#,##0.00'; PCT='0.0%'; PCT2='0.00%'; DEC1='0.0'

wb=Workbook(); wb.remove(wb.active)

def dw(v):
    return sum(2 if unicodedata.east_asian_width(c) in ('F','W') else 1 for c in str(v if v is not None else ''))
def setw(ws,widths):
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
def title(ws,row,ncol,text,size=14):
    ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=ncol)
    c=ws.cell(row,1,text); c.font=Font(name=FONT,bold=True,size=size,color='FFFFFF')
    c.fill=PatternFill('solid',fgColor=DARK); c.alignment=Alignment(horizontal='left',vertical='center',indent=1)
    ws.row_dimensions[row].height=26
def section(ws,row,ncol,text):
    ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=ncol)
    c=ws.cell(row,1,text); c.font=Font(name=FONT,bold=True,size=11,color=DARK)
    c.fill=PatternFill('solid',fgColor=LIGHT); c.alignment=Alignment(horizontal='left',vertical='center',indent=1)
    ws.row_dimensions[row].height=20
def hdr(ws,row,headers,start=1):
    for j,h in enumerate(headers,start):
        c=ws.cell(row,j,h); c.font=Font(name=FONT,bold=True,size=10,color='FFFFFF')
        c.fill=PatternFill('solid',fgColor=MID); c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
        c.border=border
    ws.row_dimensions[row].height=30
def datarow(ws,row,vals,formats=None,start=1,bold=False,fill=None,align=None):
    for j,v in enumerate(vals,start):
        c=ws.cell(row,j,v)
        c.font=Font(name=FONT,size=10,bold=bold)
        c.border=border
        if formats and formats.get(j-start+1): c.number_format=formats[j-start+1]
        if isinstance(v,str): c.alignment=Alignment(horizontal=align or 'left',vertical='center',wrap_text=True)
        else: c.alignment=Alignment(horizontal='right',vertical='center')
        if fill: c.fill=PatternFill('solid',fgColor=fill)
def para(ws,row,ncol,text,bold=False,color='000000',size=10,h=None,indent=True):
    ws.merge_cells(start_row=row,start_column=1,end_row=row,end_column=ncol)
    c=ws.cell(row,1,text); c.font=Font(name=FONT,size=size,bold=bold,color=color)
    c.alignment=Alignment(horizontal='left',vertical='top',wrap_text=True,indent=1 if indent else 0)
    if h: ws.row_dimensions[row].height=h

# ================= 01 说明与结论 =================
ws=wb.create_sheet('01_说明与结论'); setw(ws,[22,22,22,22,22,22]); ws.sheet_view.showGridLines=False
r=1; title(ws,r,6,'9月亚马逊搜索数据整体分析（搜索查询绩效 SQP × 商品推广广告搜索词报告）'); r+=2
para(ws,r,6,'数据期间：2026年9月（SQP为9月整月，广告报告为9月1日–9月30日）；分析对象：51个已导出搜索查询绩效的ASIN（以梅森罐/水升/饮品罐等玻璃容器为主）',size=10,h=30); r+=2

section(ws,r,6,'一、这两份数据分别是什么'); r+=1
rows=[
 ('数据（你的带教所说）','文件','报告类型','粒度','9月规模'),
 ('“经过处理的下载数据”','raw_data/产品9月份搜索查询绩效/ 下51个CSV（文件名=ASIN）','搜索查询绩效报告（Search Query Performance，简称SQP，亚马逊品牌分析类报表）','按月 × 按ASIN × 按搜索词','51个文件 / 3,117行 / 去重2,410个搜索词'),
 ('“真实数据”','raw_data/26.9.xlsx（表名：商品推广_搜索词_报告）','SP商品推广-搜索词报告（本店铺自己投放的广告后台数据，精确未脱敏）','按日 × 广告活动/广告组 × 客户搜索词','61,169行 / 43,846个搜索词 / 1,515个广告活动'),
 ('对照主数据','raw_data/对应关系.xlsx','ASIN对照表','ASIN → 品名/颜色/规格/型号/SKU/FNSKU','72个ASIN（其中51个有SQP）')]
hdr(ws,r,rows[0]); r+=1
for rr in rows[1:]:
    datarow(ws,r,rr); ws.row_dimensions[r].height=42; r+=1
r+=1
para(ws,r,6,'一句话理解：SQP告诉你“某个搜索词整个市场有多少曝光/点击/加购/成交、你的ASIN占了多少份额（自然+广告都算）”；广告搜索词报告告诉你“你花钱投的广告在每个词上实际带来了多少展示/点击/花费/成交”。前者是市场口径、经过亚马逊脱敏；后者是自家广告口径、精确。',h=44); r+=2

section(ws,r,6,'二、核心结论（先看这6条）'); r+=1
concl=[
 ('1','两份数据不能直接整体相除来算“广告占比”。直接把广告点击 ÷ SQP自家点击，整体会得到约336%（广告158,568次点击 ÷ SQP自家47,159次），订单约424%（16,016 ÷ 3,778），比例超过100%，说明两者口径并不构成“总体 vs 其中广告部分”的包含关系。'),
 ('2','最大原因：SQP每个ASIN只导出了“前100个搜索词”。51个文件里有27个刚好100行（已被截断）；广告报告43,846个词中，42,044个在SQP里完全没有（仅广告出现），这些长尾词贡献了64.4%的广告点击、53.2%的订单、56.9%的花费、52.9%的销售额；另有26个词SQP虽收录但你家ASIN零点击（广告侧仅122次点击、7单）。建议在后台把SQP按每个ASIN最多1,000行重新导出。'),
 ('3','即使只看两份数据“都出现”的1,776个头部词，广告点击56,260次仍大于SQP自家点击46,005次（约122%），广告订单7,488 vs 3,537（约212%）。剩余差异来自：①广告投放范围大于51个ASIN（含未导出SQP的新配色/高硼硅等变体及其他产品线）；②SQP对小数值做隐私脱敏、份额只给到0.01%；③广告按点击后7天归因，SQP按搜索当次统计。'),
 ('4','头部词上能看出明显的“自然型 vs 广告型”分化：kitchen、home、mason jars、glass water bottles 这类大词广告点击占比极低（约1%–21%），以自然流量为主；pitcher with lid、mason jar pitcher、glass pitcher with lid 这类精准购买词广告点击数接近甚至超过SQP总量，是广告投放最密集、也最受口径差异影响的词。'),
 ('5','SQP的正确用法是看“市场份额与漏斗”：在它收录的词上，自家51个ASIN合计拿到约3.42百万次曝光、4.72万次点击、1.67万次加购、3,778个订单；各环节相对市场总量的份额、以及自家点击率/加购率/转化率与市场均值的对比，才是这份报表的核心“比例”（见05、04表）。'),
 ('6','广告侧9月合计：展示803.9万、点击15.86万、花费$122,726、7天销售额$412,829、订单16,016；整体CTR约1.97%、CPC约$0.77、点击-成交率约10.1%、ACOS约29.7%、ROAS约3.36（见06、07表）。')]
for n,t in concl:
    ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=6)
    c1=ws.cell(r,1,n); c1.font=Font(name=FONT,bold=True,size=11,color='FFFFFF'); c1.fill=PatternFill('solid',fgColor=MID)
    c1.alignment=Alignment(horizontal='center',vertical='center'); c1.border=border
    c2=ws.cell(r,2,t); c2.font=Font(name=FONT,size=10); c2.alignment=Alignment(horizontal='left',vertical='top',wrap_text=True,indent=1)
    c2.border=border; ws.row_dimensions[r].height=72; r+=1
r+=1
section(ws,r,6,'三、工作簿导航'); r+=1
nav=[('02_名词解释','亚马逊官方指标术语表（以带教版本为准）＋广告报告名词补充'),
 ('03_数据总览','三份文件的类型/粒度/规模，ASIN与搜索词覆盖情况'),
 ('04_SQP_ASIN汇总','51个ASIN逐个的市场/自家曝光点击加购成交、份额与漏斗率'),
 ('05_SQP_漏斗','市场 vs 自家的搜索→曝光→点击→加购→成交全漏斗与份额'),
 ('06_广告_产品线与匹配','按广告组合(产品线)、匹配类型的CTR/CPC/ACOS/ROAS汇总'),
 ('07_广告_每日趋势','9月每日展示/点击/花费/销售额/订单趋势'),
 ('08_搜索词交叉对比','按搜索词把两份数据对齐，含广告/SQP比例与自然量推算（5,307个重点词）'),
 ('09_口径差异与脱敏','7个维度的口径差异、亚马逊脱敏机制及使用注意事项'),
 ('10_图表','漏斗、每日趋势、产品线、头部词广告vs自然对比图')]
hdr(ws,r,['Sheet','内容']); ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=6); r+=1
for a,b in nav:
    ws.cell(r,1,a).font=Font(name=FONT,size=10,bold=True,color=MID); ws.cell(r,1).border=border
    ws.cell(r,1).alignment=Alignment(horizontal='left',vertical='center',indent=1)
    ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=6)
    c=ws.cell(r,2,b); c.font=Font(name=FONT,size=10); c.alignment=Alignment(horizontal='left',vertical='center',wrap_text=True,indent=1); c.border=border
    for cc in range(2,7): ws.cell(r,cc).border=border
    ws.row_dimensions[r].height=26; r+=1
r+=1
section(ws,r,6,'四、建议和带教对齐的问题'); r+=1
qs=['“分析比例”具体指哪一种：①广告流量/自然流量占比 ②SQP里自家相对市场的份额（曝光/点击/订单份额） ③漏斗转化率（点击率/加购率/转化率/ACOS）？本次已把三类都先算好。',
    '能否在后台把每个ASIN的SQP导出条数从100提升到1,000？否则长尾词（占广告一半以上体量）无法对齐。',
    '广告搜索词报告能否增加“广告投放的ASIN/SKU”字段？目前活动名里只有约7%的行能解析出自家ASIN，无法把广告数据精确归到具体ASIN，只能到产品线/品牌级。',
    '26.9.xlsx是否只含SP商品推广？是否还有SB品牌广告/SD展示广告需要一并纳入？',
    '若要算“自然单量”，建议口径：在双方共有的头部词上，用 SQP自家成交 − 广告7天成交 作为近似自然成交，且仅对“广告≤SQP”的词采用；超出的词在08表已用红色“口径不一致”标出。']
for t in qs:
    para(ws,r,6,'· '+t,size=10,h=42); r+=1

# ================= 02 名词解释（以官方指标术语表为准） =================
ws=wb.create_sheet('02_名词解释'); ws.sheet_view.showGridLines=False
setw(ws,[15,23,67,40]); r=1
title(ws,r,4,'名词与指标解释（以亚马逊官方「指标术语表 · 亚马逊品牌分析」为准）'); r+=2
para(ws,r,4,'来源与编排：A/B/C 三部分精编自带教提供的亚马逊卖家平台「品牌分析 → 指标术语表」官方截图，定义以官方表述为准；D 部分为 26.9 广告搜索词报告的补充名词（官方术语表不覆盖广告报表）；E 部分为本次分析用到的通用概念。本次51个CSV属于 B「搜索词表现报告（搜索查询绩效）」。',h=52); r+=1
hdr(ws,r,['板块 / 环节','指标','官方定义 / 计算口径','备注 · 本次数据印证']); r+=1

def gloss_row(rr,a,b,c,d):
    datarow(ws,rr,[a,b,c,d])
    ws.cell(rr,1).font=Font(name=FONT,size=10,bold=True,color=MID)
    lc=max(1,len(str(c))//31+1); ld=max(1,len(str(d))//19+1)
    ws.row_dimensions[rr].height=max(28,14*max(lc,ld))

items=[
 ('SEC','A. 全系商品搜索表现报告（按 ASIN/目录 维度；本次未导出该报告，术语备查）'),
 ('NOTE','官方说明：通过“搜索目录”控制面板按买家搜索行为查看目录绩效，涵盖展示量、点击量、加入购物车次数、购买量；指标只包含来自搜索结果页面的数据（不包括小部件和详情页面）；搜索查询根据所选时段内ASIN展示量和点击量筛选，并非所有查询都会显示。',44),
 ('ROW','一般定义','商品名称','搜索结果页面中显示的商品名称；长度各有不同，页面最多展示前50个字符，点击列标题中的箭头可展开并获取完整详情','本次CSV未含该字段'),
 ('ROW','一般定义','ASIN编号和分类','将ASIN编号与高级分类合并为一项：①ASIN代表亚马逊商品编码，在商城中是唯一的；②分类指更高级别的分组（例如“个护健康”，如“B076906 个护健康”）；③可用ASIN编码识别商品，用分类提供其他背景信息来缩小选择范围','文件名即ASIN；分类对应04表“产品线”'),
 ('ROW','一般定义','当日达配送速度','客户将在购买当天收到商品；记录搜索结果页中显示的、带“当日达”消息的ASIN被浏览/点击/加入购物车/已购买的次数。在很多地区少于2天的配送通常被视为“快速”配送；使用“当日达”，买家订单可在24小时内处理、打包和配送','帮助了解当日达配送对商品绩效的影响'),
 ('ROW','一般定义','1天配送速度','记录带“一日送达/次日达”消息的ASIN被浏览/点击/加购/购买的次数；与当日达相比，这种方式为卖家留出更多空间安排收到的订单，并需格外注意包装和供货情况','配送速度对比之一'),
 ('ROW','一般定义','2天配送速度','记录带“两日送达”消息的ASIN被浏览/点击/加购/购买的次数；比较当日达/次日达/两日达指标的配送速度，可帮助了解配送速度对商品互动度和转化率的影响','配送速度对比之一'),
 ('ROW','一般定义','商品价格（中位数）','“已展示/已点击/已加入购物车”的ASIN在搜索结果页显示的中位数商品价格；购买价格会因优惠券、折扣、运费、礼品卡等不同：导致购买价高于展示/点击/加购价的因素包括运费、税费、礼品卡（Audible有声读物对会员免费、非会员不免费），导致购买价更低的因素包括优惠券、折扣、账户款项','用于判断商品价格是否在展示、点击、加购和购买方面起作用'),
 ('SEC','A-1 搜索漏斗 · 展示量'),
 ('ROW','展示量','总展示量','所选时段内所有搜索查询的搜索结果页面产生的展示总次数：该ASIN在搜索结果页每显示一次记一次，同一页面自然位与推广位各显示一次（两次）则记两次。①包含自然搜索商品和推广商品，但不含“编辑推荐/评分最高/评分较高”等模块中展示的ASIN；②只要商品向买家展示过，无论在可滚动视图还是非首屏位置都计入（假设商品排在第16位、买家向下滚动才看到，仍记为一次展示）；③包含已加载给买家页面上的ASIN（如搜索结果第2页），不含没有获得浏览量的次级页面（如第10页且没有买家点击过）；④包含来自二次细化查询的展示（搜“胶囊咖啡”后通过“中度烘焙”细化查询、商品再次展示，则再记一次）','对应CSV“曝光总量 / ASIN曝光计数”'),
 ('SEC','A-2 搜索漏斗 · 点击量'),
 ('ROW','点击量','总点击量','特定时段内搜索结果页面产生的ASIN总点击量（总浏览次数）；当买家从搜索页面进入并加载ASIN详情页面时，点击次数才被计入，务必与展示量一起通盘考虑','对应CSV“点击总量”'),
 ('ROW','点击量','点击率（CTR）','CTR是最具影响力的指标之一，包含搜索结果页面产生的ASIN点击量与展示量占比，可帮助确定整体商品质量：①CTR代表商品获得的参与度，例如ASIN获得10,000次展示、300次点击，则CTR为3%；②点击率没有参考值，它因商品类型、设备类型（移动/桌面）、查询内容而异','注意：此为“全系商品报告”口径，CTR＝点击÷展示'),
 ('SEC','A-3 搜索漏斗 · 加入购物车'),
 ('ROW','加入购物车','总加购次数','特定时段内搜索结果页面产生的ASIN加入购物车总次数：①买家可以从多个页面（如商品详情页）将商品加购，只要该ASIN在搜索结果页展示过并且被加购，就计为一次；②买家可能从外部网站转到商品详情页加购，这类加购不会计入，因为它们并非来源于搜索','对应CSV“加购总数”'),
 ('SEC','A-4 搜索漏斗 · 购买次数'),
 ('ROW','购买次数','总购买次数','特定时段内搜索结果页面产生的ASIN总购买次数：①仅包含买家购买商品时的购买次数，不会排除已取消和已退货的商品购买；②一次购买操作中购买了同一ASIN的多件（如5件）商品，只视为一次购买；③可能与销售报告总销量不一致——只包含归因于搜索结果页面的购买，不包含“评分最高/新品”等模块及搜索结果页之外（首页或详情页直接下单）的成交；④包含一天内的购买次数：从查询到展示/点击/加购/购买所有操作都应在24小时内进行（归因时段24小时），查询后当天加购、第二天才购买的不计入该指标归因','对应CSV“下单总数”'),
 ('ROW','购买次数','搜索流量销售额','指定时段内由搜索结果页面产生的所有销售收入总和：①此处为所售商品的总数量，与赚多少钱或是否盈利无关；②与销售报告比较会发现不一致——此总销量仅包含来自搜索结果页面ASIN的销量，买家通过外部流量访问相关ASIN详情页等不含在内','广告报告“7天销售额”为另一口径'),
 ('ROW','购买次数','转化率','描述买家从点击到购买的成功转化，包含搜索结果页面产生的ASIN购买次数与点击量百分比；此处转化率由购买之前24小时内是否在搜索场景下发现该商品决定，过去24小时内买家从外部网站直接访问详情页并购买的，系统不会包含这次购买','广告报告CVR＝订单÷广告点击，口径不同'),
 ('ROW','购买次数','评级（中位数）','已购买的ASIN在“搜索”中显示的中位数评级：①买家评论评分从很差(1)到优秀(5)；②商品的展示评分与购买评分通常变化很小，中位数评分在评论量较少的早期通常不稳定，随评论量增加会稳定下来','本次CSV未含该字段'),
 ('SEC','B. 搜索词表现报告（按搜索词维度）＝ 本次51个CSV（搜索查询绩效）'),
 ('NOTE','官方说明：通过“搜索查询绩效”控制面板，可根据买家的搜索行为查看搜索词的绩效，显示所选时段内品牌目录或ASIN的热门搜索词指标（展示量、点击量、加入购物车次数和购买量）；购买量和销售总额可能与销售报告总计不一致（口径同A）；搜索查询根据所选时段内ASIN展示量和点击量选择，并非所有查询都会显示。',44),
 ('ROW','一般定义','搜索查询得分','每个搜索查询的绩效排名（从高到低）；目前官方公开显示排名前1,000位的查询，此列无法隐藏；使用展示量、点击量、加入购物车和购买次数以及品牌表现情况来综合计算每个搜索词的表现并排序，默认情况下排名按照得分从高到低排序','本次实测：每个ASIN文件内得分恰为1、2、3…连续编号（1＝对该ASIN最重要的词），与搜索量几乎无关、与该ASIN自家点击/成交强相关；本次仅导出前100名，建议按官方上限1,000重导'),
 ('ROW','一般定义','搜索查询词条','买家搜索的关键词词条，此列无法隐藏：①不会按主题对词条分组，您看到的就是买家输入的内容；②将包含与所选品牌相关的查询，若未来引入新分类（例如“咖啡杯”），与咖啡杯相关的查询也会被包含；③查询包括“广泛购买意图”或“具体购物意图”查询','即CSV“搜索查询”列，是两表对齐的最小单位'),
 ('ROW','一般定义','查询数量','选定时间段内搜索此词条的次数：将包括一天内发出的所有查询，如果同一买家会话在24小时内多次提交相同查询，会将这些查询实例计入总查询量；此外，点击下一页搜索结果将增加搜索量','即CSV“搜索查询量”，是词维度各“率”的分母'),
 ('ROW','一般定义','当日达/1天/2天配送速度','含义同A部分，区别是按“特定查询”统计：记录带相应配送消息的ASIN在特定查询的搜索结果页中被浏览/点击/加购/购买次数，并会将浏览时的配送速度延展到所有下游操作（点击、加入、购买）','CSV含各环节配送速度分布列'),
 ('ROW','一般定义','商品价格（中位数）','所有ASIN在该查询结果中展现时的中位数价格；商品价格不含运费和税费','注意与A部分（含运费税费情形）的口径差异'),
 ('ROW','一般定义','品牌价格（中位数）','该品牌的所有ASIN在该查询结果中展现时的中位数价格；商品价格不含运费和税费','—'),
 ('NOTE','每个漏斗环节（展示/点击/加购/购买）都有5个指标：总计数（全市场所有卖家）、品牌数量（你的品牌）、品牌占有率（＝品牌数量÷总计数）、ASIN数量（所选ASIN）、ASIN份额（＝ASIN数量÷总计数）。',30),
 ('SEC','B-1 搜索漏斗 · 展示量（词维度）'),
 ('ROW','展示量','总计数','来自搜索结果的所有ASIN的总展示次数：①每当ASIN在该搜索结果页显示一次即记为一次展示；②包含自然搜索商品和推广商品，不含“编辑推荐/评分最高/评分较高”模块；③包含向买家展示的商品，无论在可滚动视图还是非首屏位置（假设“咖啡易滤包”展示在第16位、买家下滑列表才能看到，仍计一次）；④包含已向买家显示页面中的ASIN（如第2页），不含未获浏览量页面（如第10页、从未有买家点到）；⑤包含来自二次细化查询的展示','CSV“曝光总量”（市场）'),
 ('ROW','展示量','品牌数量','来源于搜索结果的所选品牌ASIN的总展示次数；品牌数量在品牌级别计算，包含所选时间段内某个商品的所有报价','品牌＝你店铺/品牌下全部ASIN'),
 ('ROW','展示量','品牌占有率','品牌展示量占总展示量的百分比 ＝ 品牌数量 ÷ 总计数','即品牌曝光份额'),
 ('ROW','展示量','ASIN数量','此查询中所选ASIN的总展示次数','CSV“曝光量：ASIN 计数”'),
 ('ROW','展示量','ASIN份额','与查询的总次数相比，归因于ASIN的展现量所占的百分比份额 ＝ ASIN数量 ÷ 总计数','CSV“曝光：ASIN 曝光占比%”'),
 ('SEC','B-2 搜索漏斗 · 点击量（词维度）'),
 ('ROW','点击量','总计数','在该查询的搜索结果页面中被点击的次数','CSV“点击量：总次数”'),
 ('ROW','点击量','品牌数量','您的品牌商品在该查询结果页面产生的点击量；品牌数量在品牌级别计算，包含所选时间段内某个商品的所有报价','—'),
 ('ROW','点击量','品牌占有率','品牌点击量占总点击量的百分比 ＝ 品牌数量 ÷ 总计数','—'),
 ('ROW','点击量','点击率（CTR）','总点击次数除以搜索查询量；可用来衡量买家在进行相关查询时与您的商品互动的程度','分母是搜索量（不是展示）；与全系商品报告、广告报告的CTR分母都不同，严禁直接相比'),
 ('ROW','点击量','ASIN数量 / ASIN份额','ASIN数量＝本次查询所选ASIN的总点击量；ASIN份额＝与查询总次数相比、归因于ASIN的点击次数所占百分比 ＝ ASIN数量 ÷ 总计数','CSV“点击量：ASIN 数量 / ASIN 份额%”'),
 ('SEC','B-3 搜索漏斗 · 加入购物车（词维度）'),
 ('ROW','加入购物车','总计数','在该查询的搜索结果页面中被加入购物车的次数：①买家可以从多个页面（如商品详情页）加购，只要该ASIN在搜索结果页展示过并且被加购即计一次；②买家从外部网站直接访问详情页的加购不会计入，因为并非来源于搜索','CSV“购物车添加：总数”'),
 ('ROW','加入购物车','品牌数量','针对此查询展示的品牌目录所带来的加入购物车商品总数量；官方明确“品牌计数仅基于自然产生的/非广告的销售数据”，品牌购买数量是该品牌的所有子ASIN；在品牌级别计算、包含该商品所有报价','注意：加购环节品牌数为非广告口径'),
 ('ROW','加入购物车','品牌占有率','品牌加购次数占总加购次数的百分比 ＝ 品牌数量 ÷ 总计数','—'),
 ('ROW','加入购物车','加入购物车次数（率）','被加入购物车的总次数除以搜索查询量；追踪该指标非常重要，它显示了买家对您商品的强烈购买意向，通过比较加入购物车比率和购买率，可获得已成功转换和已放弃购物车添加的详细信息','CSV“加购率%”'),
 ('ROW','加入购物车','ASIN数量 / ASIN份额','ASIN数量＝此查询所选ASIN被加入购物车的总次数；ASIN份额＝与总次数相比、归因于ASIN的加购次数所占百分比 ＝ ASIN数量 ÷ 总计数','CSV“加购：ASIN 数量 / ASIN 加购占比%”'),
 ('SEC','B-4 搜索漏斗 · 购买次数（词维度）'),
 ('ROW','购买次数','总计数','根据查询的搜索结果，在所选亚马逊商城中所有品牌发生的购买总数：①仅包含在该查询下买家购买商品时的购买次数，不会排除已取消和已退货的商品购买；②一次购买操作购买了同一ASIN的多件（如5件）商品，只视为一次购买；③包含一天内的购买次数——从查询和所有漏斗指标（展示/点击/加购/购买）开始，所有操作都应在24小时内进行，当天查询并加购、第二天才购买的不计入该指标归因范围','CSV“购买：下单总数”'),
 ('ROW','购买次数','购买率','购买总量除以搜索查询量；是一项衡量搜索查询转化为亚马逊商城实际购买效率的指标，计算方式：购买率 ＝ 总数 ÷ 搜索查询量','CSV“成交转化率%”'),
 ('ROW','购买次数','品牌数量','针对此查询展示的选定品牌目录所带来的总购买量；品牌数量在品牌级别计算，包含所选时间段内某个商品的所有报价','—'),
 ('ROW','购买次数','品牌占有率','从品牌目录购买的商品数量除以查询总数得出的百分比份额 ＝ 品牌数量 ÷ 总计数','—'),
 ('ROW','购买次数','ASIN数量 / ASIN份额','ASIN数量＝此查询所选ASIN的总购买量；ASIN份额＝归因于ASIN的购买操作数量占查询总数的百分比 ＝ ASIN数量 ÷ 总计数','CSV“下单成交：ASIN 数量 / ASIN 占比%”，衡量市场地位最关键的指标'),
 ('SEC','C. 重复购买控制面板（本次数据未导出，备查）'),
 ('NOTE','官方说明：“重复购买”控制面板按品牌和ASIN分析买家保留情况和重复购买行为，显示所选时段内的回购商品销量、回购商品件数和回购买家（包括“订购省”买家）数量指标；“品牌”视图针对与品牌关联的所有ASIN计算，ASIN视图显示所选ASIN的特定指标，即使同一报告时间范围内，品牌和ASIN视图之间的指标值也会有所不同。',44),
 ('ROW','一般定义','商品名称 / 订单总数','商品名称＝搜索结果和详情页面中显示的商品名称；订单总数＝指定品牌或ASIN的订单总数，一个订单可能包含多件同款商品，因此订单数量与订购商品数量不同','订单数≠商品件数，对应广告报告“7天订单数/销售量”'),
 ('ROW','重复订购商品销售额','销售额 / 与上一时段相比的变化 / 在总销售额中所占百分比','销售额＝在报告时间范围内下了多个订单的买家所产生的已购商品销售额；另含与最近前一周期相比的变化百分比、以及重复订购商品销售额在订购商品总销售额中的占比','衡量回头客贡献'),
 ('ROW','重复订购商品数量','商品数量 / 变化 / 占比','商品数量＝在报告时间范围内下了多个订单的买家所购买商品的单位数量；另含环比变化百分比、占商品总销量的百分比','回头客购买件数'),
 ('ROW','重购买家数量','回头客 / 与上一时段相比的变化','回头客＝在报告时间范围内下了多个订单的唯一身份买家数量；另含环比变化百分比','复购人数'),
 ('ROW','重购买家占比','买家占比 / 与上一时段相比的变化','重购买家在所选报告时间范围内下单的所有买家中所占的百分比；另含环比变化百分比','复购率'),
 ('SEC','D. 广告搜索词报告名词（26.9.xlsx · SP商品推广；官方术语表未覆盖，我方补充）'),
 ('ROW','广告','展示量 Impressions','你的广告被展示的次数（仅广告位）','9月合计803.9万'),
 ('ROW','广告','点击量 / CTR','广告点击次数；广告CTR ＝ 点击量 ÷ 展示量','与搜索词报告CTR（点击÷搜索量）分母不同，勿直接比较；9月约1.97%'),
 ('ROW','广告','CPC 单次点击成本','＝ 花费 ÷ 点击量，每次广告点击的平均成本','9月约$0.77'),
 ('ROW','广告','花费 Spend','广告实际扣费金额（美元）','9月合计$122,726'),
 ('ROW','广告','7天总销售额','广告点击后7天内带来的销售额（含广告SKU和店铺其他SKU连带成交）','9月$412,829'),
 ('ROW','广告','7天订单数 / 销售量','点击后7天内归因的订单笔数 / 商品件数','9月16,016单'),
 ('ROW','广告','ACOS 广告投入产出比','＝ 花费 ÷ 7天总销售额，越低越“划算”','整体约29.7%'),
 ('ROW','广告','ROAS 广告投资回报率','＝ 7天总销售额 ÷ 花费 ＝ 1/ACOS，即花1元换回的销售额','整体约3.36'),
 ('ROW','广告','7天转化率','＝ 7天订单数 ÷ 点击量','整体约10.1%'),
 ('ROW','广告','广告SKU / 其他SKU','广告商品本身成交 vs 同店铺其他商品被连带成交的销售量/销售额，用于看广告的引流外溢效果','—'),
 ('ROW','广告','投放 Targeting / Keyword','手动广告中你出价的关键词或定位对象（也可能是竞品ASIN，如B0开头编码）','与“客户搜索词”不是一回事'),
 ('ROW','广告','客户搜索词 Customer Search Term','买家实际输入并触发你广告的词；广泛/词组/自动匹配下，它通常比“投放”词更多、更长','两表对齐的最小单位'),
 ('ROW','广告','匹配类型','EXACT精准 / PHRASE词组 / BROAD广泛；“-”表示自动广告（含紧密匹配、宽泛匹配、同类商品、关联商品四种）','本次以自动广告行为主'),
 ('ROW','广告','广告组合/活动/广告组','Portfolio / Campaign / Ad Group，广告管理三级结构；本报告用“广告组合”近似代表产品线（梅森罐、水升、饮品罐等）','见06表'),
 ('ROW','广告','归因窗口（7天）','广告报告把点击后7天内的成交都归因给这次点击，可跨日、跨词','SQP为查询后24小时当次归因，是两表对不上的原因之一'),
 ('SEC','E. 本次分析用到的通用概念'),
 ('ROW','概念','ASIN','亚马逊商品编码（Amazon Standard Identification Number），每个颜色/规格变体一个，B0开头10位','对应关系表共72个，其中51个有CSV'),
 ('ROW','概念','自然流量 vs 广告流量','自然（Organic）＝搜索结果自然排名带来的免费流量；广告（Sponsored）＝付费广告位。搜索词报告的“ASIN数量”自然+广告都包含，广告报告只有广告部分','加购/购买环节的“品牌数量”官方说明仅基于自然/非广告数据'),
 ('ROW','概念','脱敏 / 隐私阈值','亚马逊为防止数据泄露：低流量词不展示、份额百分比只给到0.01%、小数值屏蔽；你能看到市场总量和自家份额，看不到任何具体竞品的明细','实测由“总量×份额”反推计数存在误差（曝光最大差约1,461次、点击约18次、订单约1次）'),
 ('ROW','概念','Top100 截断','搜索查询得分官方公开前1,000名；本次每个ASIN仅导出前100名（27/51个达到上限），长尾词缺失','建议后台按1,000条/ASIN重新导出'),
 ('ROW','概念','市场份额 / 搜索漏斗','份额＝自家（品牌或ASIN）计数 ÷ 市场总计数；搜索漏斗＝搜索→展示→点击→加购→购买的逐层转化','见04、05表'),
]
for it in items:
    if it[0]=='SEC':
        section(ws,r,4,it[1]); r+=1
    elif it[0]=='NOTE':
        para(ws,r,4,it[1],size=9,h=it[2]); r+=1
    else:
        gloss_row(r,it[1],it[2],it[3],it[4]); r+=1
ws.freeze_panes='A5'

# ================= 03 数据总览 =================
ws=wb.create_sheet('03_数据总览'); ws.sheet_view.showGridLines=False
setw(ws,[26,40,30,26,40]); r=1
title(ws,r,5,'数据总览与覆盖情况'); r+=2
section(ws,r,5,'A. 三份文件'); r+=1
hdr(ws,r,['数据','文件/位置','报告类型','粒度','规模']); r+=1
inv=[('SQP搜索查询绩效（处理后）','产品9月份搜索查询绩效/ 下51个CSV','搜索查询绩效 SQP（市场口径，脱敏）','月 × ASIN × 搜索词','51文件 / 3,117行 / 2,410个去重词 / 51 ASIN'),
 ('广告搜索词报告（真实）','26.9.xlsx · 商品推广_搜索词_报告','SP商品推广搜索词（自家广告，精确）','日 × 活动 × 搜索词','61,169行 / 43,846个词 / 1,515个活动 / 1,530个广告组'),
 ('ASIN对照主数据','对应关系.xlsx','主数据映射','ASIN维度','72个ASIN（51个有SQP，21个未导出）')]
for rr in inv:
    datarow(ws,r,rr); ws.row_dimensions[r].height=40; r+=1
r+=1
section(ws,r,5,'B. ASIN覆盖（对应关系表72个ASIN中，21个没有SQP文件）'); r+=1
hdr(ws,r,['项目','数量','说明','','']); r+=1
covrows=[('对应关系表ASIN总数',72,'店铺在售变体（梅森罐32/64oz各颜色、果茶/滤棒/高硼硅款、水升、饮品罐、洗衣罐、糖罐、玻璃套装等）'),
 ('已导出SQP的ASIN',51,'本次04/05表的分析范围'),
 ('未导出SQP的ASIN',21,'主要是高硼硅梅森罐5个、32oz新配色9个、64oz米色/深灰等新变体7个；广告仍可能投放到这些ASIN')]
for a,b,c in covrows:
    ws.cell(r,1,a).border=border; ws.cell(r,1).font=Font(name=FONT,size=10)
    ws.cell(r,2,b).border=border; ws.cell(r,2).number_format=INT; ws.cell(r,2).alignment=Alignment(horizontal='right')
    ws.merge_cells(start_row=r,start_column=3,end_row=r,end_column=5)
    ws.cell(r,3,c).border=border; ws.cell(r,3).alignment=Alignment(wrap_text=True,vertical='center'); ws.cell(r,3).font=Font(name=FONT,size=10)
    for cc in range(4,6): ws.cell(r,cc).border=border
    ws.row_dimensions[r].height=34; r+=1
r+=1
section(ws,r,5,'C. 搜索词覆盖与“比例失真”测算（品牌级，按归一化搜索词匹配；集合口径）'); r+=1
hdr(ws,r,['搜索词分类','词数','SQP自家点击','广告点击','广告花费 / 销售额 / 订单']); r+=1
ccov=[('双方都出现（集合交集；其中1,776个双方都有点击）',cov['interset_n'],cov['interset_sqp_clk'],cov['interset_ad_clk'],'$%.0f / $%.0f / %.0f单'%(cov['interset_ad_spend'],cov['interset_ad_sales'],cov['interset_ad_ord'])),
 ('仅SQP出现（广告报告无此词；608个中595个有自家点击）',cov['sqponlyset_n'],cov['sqponlyset_sqp_clk'],0,'—'),
 ('仅广告出现（SQP完全未收录的长尾词）',cov['adonlyset_n'],0,cov['adonlyset_ad_clk'],'$%.0f / $%.0f / %.0f单'%(cov['adonlyset_ad_spend'],cov['adonlyset_ad_sales'],cov['adonlyset_ad_ord']))]
cstart=r
for a,b,c,d,e in ccov:
    datarow(ws,r,[a,b,c,d,e],formats={2:INT,3:INT,4:INT}); ws.row_dimensions[r].height=34; r+=1
datarow(ws,r,['合计 / 全量（两表并集）',f'=SUM(B{cstart}:B{r-1})',f'=SUM(C{cstart}:C{r-1})',f'=SUM(D{cstart}:D{r-1})',
              '$%.0f / $%.0f / %.0f单'%(cov['ad_spend_total'],cov['ad_sales_total'],cov['ad_ord_total'])],
        formats={2:INT,3:INT,4:INT},bold=True,fill=LIGHT); ws.row_dimensions[r].height=30; r+=2
para(ws,r,5,'勾稽关系：SQP 2,410词 ＝ 共有1,802 ＋ 仅SQP 608；广告43,846词 ＝ 共有1,802 ＋ 仅广告42,044（广告原始写法43,847个，归一化小写/去首尾空格后为43,846个——“glass  container”双空格与“glass container”合并为1个）。①共有词覆盖了SQP 97.6%的自家点击（46,005/47,159），SQP头部词基本都投了广告；②仅广告出现的词占全店广告点击64.4%、订单53.2%、花费56.9%、销售额52.9%，这部分在当前SQP导出里完全缺失，是“广告÷SQP>100%”的首要原因。',h=58,bold=True,color=WARN); r+=1
para(ws,r,5,'口径提示：08表按“能否与SQP自家点击对齐”分桶，把42,044个未收录词 ＋ 39个“SQP收录但自家0点击”的词（其中26个广告侧有点击，仅122次点击/7单/$92/$194；另13个广告报告里也没有）合并为42,083行；交集1,802个词中有26个你家SQP零点击，故“双方都有点击”的词为1,776个。两种口径只差这39个零点击词，比例差不超过0.1个百分点。',h=46); r+=1

# ================= 04 SQP ASIN汇总 =================
ws=wb.create_sheet('04_SQP_ASIN汇总'); ws.sheet_view.showGridLines=False
cols=['ASIN','品名','颜色','规格','产品线','收录搜索词数','Top100截断','头号搜索词(排名1)','市场搜索量(覆盖词)','市场曝光','市场点击','市场加购','市场下单',
      '自家曝光','自家点击','自家加购','自家下单','曝光份额','点击份额','订单份额','自家点击率(点/曝)','加购率(加/点)','成交率(单/点)']
setw(ws,[12,24,8,10,16,10,9,26,14,12,11,10,10,11,10,10,10,9,9,9,12,11,11])
r=1; title(ws,r,len(cols),'SQP 分ASIN汇总（市场口径按词去重，自家口径为该ASIN全部收录词合计）'); r+=1
hdr(ws,r,cols); r+=1
fmts={6:INT,9:INT,10:INT,11:INT,12:INT,13:INT,14:INT,15:INT,16:INT,17:INT,18:PCT2,19:PCT2,20:PCT2,21:PCT,22:PCT,23:PCT}
firstdata=r
for _,x in asin_sum.iterrows():
    vals=[x.ASIN,x.品名,x.颜色,x.规格,x.产品线,int(x['收录搜索词数']),x['是否Top100截断'],x['头号搜索词(排名1)'],
          int(x['市场搜索查询量(覆盖词)']),int(x['市场曝光总量']),int(x['市场点击总量']),int(x['市场加购总量']),int(x['市场下单总量']),
          int(x['自家曝光']),int(x['自家点击']),int(x['自家加购']),int(x['自家下单']),
          f'=IF(J{r}=0,"",N{r}/J{r})',f'=IF(K{r}=0,"",O{r}/K{r})',f'=IF(M{r}=0,"",Q{r}/M{r})',
          f'=IF(N{r}=0,"",O{r}/N{r})',f'=IF(O{r}=0,"",P{r}/O{r})',f'=IF(O{r}=0,"",Q{r}/O{r})']
    datarow(ws,r,vals,formats=fmts)
    r+=1
lastd=r-1
# totals
tot=['合计','51个ASIN','','','',f'=SUM(F{firstdata}:F{lastd})','','',
     f'=SUM(I{firstdata}:I{lastd})',f'=SUM(J{firstdata}:J{lastd})',f'=SUM(K{firstdata}:K{lastd})',f'=SUM(L{firstdata}:L{lastd})',f'=SUM(M{firstdata}:M{lastd})',
     f'=SUM(N{firstdata}:N{lastd})',f'=SUM(O{firstdata}:O{lastd})',f'=SUM(P{firstdata}:P{lastd})',f'=SUM(Q{firstdata}:Q{lastd})',
     f'=N{r}/J{r}',f'=O{r}/K{r}',f'=Q{r}/M{r}',f'=O{r}/N{r}',f'=P{r}/O{r}',f'=Q{r}/O{r}']
datarow(ws,r,tot,formats=fmts,bold=True,fill=LIGHT)
ws.freeze_panes='C3'
ws.auto_filter.ref=f'A2:{get_column_letter(len(cols))}{lastd}'

# ================= 05 SQP 漏斗 =================
ws=wb.create_sheet('05_SQP_漏斗'); ws.sheet_view.showGridLines=False
setw(ws,[16,16,16,18,16,16,14,40]); r=1
title(ws,r,8,'SQP 全市场 vs 自家（51个ASIN）搜索漏斗 · 2026年9月'); r+=2
hdr(ws,r,['漏斗环节','市场总量','市场环比转化率','报告口径率(/搜索量)','自家总量','自家环比转化率','自家份额(自家/市场)','说明']); r+=1
V,I,C,A,O=mkt_tot['vol'],mkt_tot['impr'],mkt_tot['clk'],mkt_tot['add'],mkt_tot['ord']
oi,oc,oa,oo=own_tot['impr'],own_tot['clk'],own_tot['add'],own_tot['ord']
funnel=[
 ('搜索查询量',int(V),None,None,None,None,None,'去重后2,410个搜索词的搜索次数合计'),
 ('曝光',int(I),'=B5/B4',None,int(oi),None,'=E5/B5','一次搜索结果页可展示多个商品，故曝光>搜索量'),
 ('点击',int(C),'=B6/B5','=B6/B4',int(oc),'=E6/E5','=E6/B6','SQP报告“点击率”=点击/搜索量；广告CTR=点击/展示，两者不同'),
 ('加入购物车',int(A),'=B7/B6','=B7/B4',int(oa),'=E7/E6','=E7/B7','加购是成交的先行指标'),
 ('下单成交',int(O),'=B8/B7','=B8/B4',int(oo),'=E8/E6','=E8/B8','报告口径“成交转化率”=下单/搜索量；自家环比用下单/点击')]
ff={2:INT,3:PCT,4:PCT,5:INT,6:PCT,7:PCT2}
for rr in funnel:
    datarow(ws,r,list(rr),formats=ff); ws.row_dimensions[r].height=30; r+=1
r+=1
para(ws,r,8,'注：市场总量按搜索词去重（同一词在多个ASIN文件中只计一次）；自家总量按ASIN×词逐条相加，同一搜索结果页出现多个自家变体会分别计数，与市场总量同为“商品展示次数”口径，可直接相除得份额。SQP数值经亚马逊脱敏（份额仅0.01%精度、小值屏蔽），份额为近似值。',h=44); r+=2
# 份额速览
section(ws,r,8,'自家市场份额速览'); r+=1
sh=['=E5/B5','=E6/B6','=E7/B7','=E8/B8']; shnames=['曝光份额','点击份额','加购份额','订单份额']
hdr(ws,r,['指标','份额','','','','','','']); r+=1
for a,fm in zip(shnames,sh):
    ws.cell(r,1,a).border=border; ws.cell(r,1).font=Font(name=FONT,size=10)
    c=ws.cell(r,2,fm); c.number_format=PCT2; c.border=border; c.alignment=Alignment(horizontal='right'); c.font=Font(name=FONT,size=10,bold=True)
    for cc in range(3,9): ws.cell(r,cc).border=border
    r+=1

# ================= 06 广告 产品线与匹配 =================
ws=wb.create_sheet('06_广告_产品线与匹配'); ws.sheet_view.showGridLines=False
cols6=['广告组合(近似产品线)','归并产品线','展示量','点击量','CTR','CPC','花费','7天销售额','订单数','销售量','转化率CVR','ACOS','ROAS','花费占比','销售额占比']
setw(ws,[26,30,11,9,8,8,11,12,9,9,10,9,8,9,10])
r=1; title(ws,r,len(cols6),'广告汇总（SP商品推广 · 2026年9月）'); r+=2
section(ws,r,len(cols6),'A. 按广告组合（产品线）'); r+=1
hdr(ws,r,cols6); r+=1
tot_spend=port_sum['花费'].sum(); tot_sales=port_sum['7天销售额'].sum()
fd=r
totrow_idx=fd+len(port_sum)
for _,x in port_sum.iterrows():
    vals=[x['广告组合名称'],x['产品线'],int(x['展示量']),int(x['点击量']),round(x['CTR'],4) if pd.notna(x['CTR']) else None,
          round(x['CPC'],3) if pd.notna(x['CPC']) else None,round(x['花费'],2),round(x['7天销售额'],2),int(x['订单数']),int(x['销售量']),
          round(x['转化率CVR'],4) if pd.notna(x['转化率CVR']) else None,round(x['ACOS'],4) if pd.notna(x['ACOS']) else None,
          round(x['ROAS'],3) if pd.notna(x['ROAS']) else None,
          f'=G{r}/$G${totrow_idx}',f'=H{r}/$H${totrow_idx}']
    datarow(ws,r,vals,formats={3:INT,4:INT,5:PCT,6:MONEY,7:MONEY,8:MONEY,9:INT,10:INT,11:PCT,12:PCT,13:'0.00',14:PCT,15:PCT}); r+=1
ld=r-1
totrow=['合计','',f'=SUM(C{fd}:C{ld})',f'=SUM(D{fd}:D{ld})',f'=D{r}/C{r}',f'=G{r}/D{r}',f'=SUM(G{fd}:G{ld})',f'=SUM(H{fd}:H{ld})',
        f'=SUM(I{fd}:I{ld})',f'=SUM(J{fd}:J{ld})',f'=I{r}/D{r}',f'=G{r}/H{r}',f'=H{r}/G{r}',
        f'=SUM(N{fd}:N{ld})',f'=SUM(O{fd}:O{ld})']
datarow(ws,r,totrow,formats={3:INT,4:INT,5:PCT,6:MONEY,7:MONEY,8:MONEY,9:INT,10:INT,11:PCT,12:PCT,13:'0.00',14:PCT,15:PCT},bold=True,fill=LIGHT)
r+=2
section(ws,r,len(cols6),'B. 按匹配类型'); r+=1
hdr(ws,r,['匹配类型','','展示量','点击量','CTR','CPC','花费','7天销售额','订单数','销售量','转化率CVR','ACOS','ROAS','花费占比','销售额占比']); r+=1
for _,x in match_sum.sort_values('花费',ascending=False).iterrows():
    vals=[x['匹配类型中文'],'',int(x['展示量']),int(x['点击量']),round(x['CTR'],4),round(x['CPC'],3),round(x['花费'],2),round(x['7天销售额'],2),
          int(x['订单数']),int(x['销售量']),round(x['转化率CVR'],4),round(x['ACOS'],4) if pd.notna(x['ACOS']) else None,
          round(x['ROAS'],3) if pd.notna(x['ROAS']) else None,
          f'=G{r}/$G${totrow_idx}',f'=H{r}/$H${totrow_idx}']
    datarow(ws,r,vals,formats={3:INT,4:INT,5:PCT,6:MONEY,7:MONEY,8:MONEY,9:INT,10:INT,11:PCT,12:PCT,13:'0.00',14:PCT,15:PCT}); r+=1
ws.freeze_panes='A5'

# ================= 07 每日趋势 =================
ws=wb.create_sheet('07_广告_每日趋势'); ws.sheet_view.showGridLines=False
cols7=['日期','展示量','点击量','CTR','CPC','花费','7天销售额','订单数','转化率CVR','ACOS']
setw(ws,[12,11,9,8,8,11,12,9,10,9]); r=1
title(ws,r,len(cols7),'广告每日趋势 · 2026年9月'); r+=2
hdr(ws,r,cols7); r+=1
d0=r
for _,x in daily.iterrows():
    vals=[x['开始日期'].strftime('%m-%d'),int(x['展示量']),int(x['点击量']),round(x['CTR'],4),round(x['CPC'],3),round(x['花费'],2),
          round(x['7天销售额'],2),int(x['订单数']),round(x['转化率CVR'],4) if pd.notna(x['转化率CVR']) else None,
          round(x['ACOS'],4) if pd.notna(x['ACOS']) else None]
    datarow(ws,r,vals,formats={2:INT,3:INT,4:PCT,5:MONEY,6:MONEY,7:MONEY,8:INT,9:PCT,10:PCT}); r+=1
d1=r-1
datarow(ws,r,['合计/均值',f'=SUM(B{d0}:B{d1})',f'=SUM(C{d0}:C{d1})',f'=C{r}/B{r}',f'=F{r}/C{r}',f'=SUM(F{d0}:F{d1})',
              f'=SUM(G{d0}:G{d1})',f'=SUM(H{d0}:H{d1})',f'=H{r}/C{r}',f'=F{r}/G{r}'],
        formats={2:INT,3:INT,4:PCT,5:MONEY,6:MONEY,7:MONEY,8:INT,9:PCT,10:PCT},bold=True,fill=LIGHT)
ws.freeze_panes='A4'

# ================= 08 搜索词交叉对比 =================
ws=wb.create_sheet('08_搜索词交叉对比'); ws.sheet_view.showGridLines=False
cols8=['搜索词(归一化小写)','匹配状态','出现ASIN数','市场月搜索量','SQP自家曝光','SQP自家点击','SQP自家加购','SQP自家下单',
       '广告展示量','广告点击','广告花费','广告7天销售额','广告订单','广告点击/SQP点击','广告订单/SQP订单','推算自然点击','推算自然订单','口径提示']
setw(ws,[34,22,9,12,11,10,10,10,11,9,10,12,9,12,12,11,11,20])
r=1; title(ws,r,len(cols8),'搜索词交叉对比（品牌级；收录全部双方共有/仅SQP词，及广告中点击≥5的长尾词，共5,307个）'); r+=1
para(ws,r,len(cols8),'比例列=广告÷SQP自家：≤100%时“推算自然量=SQP−广告”可作近似参考；>100%表示广告数大于SQP总量（Top100截断/ASIN范围/7天归因等口径差异），不可用来反推自然量，已标红。',h=28,bold=True,color=WARN); r+=1
hdr(ws,r,cols8); r+=1
fd=r
warn_fill=PatternFill('solid',fgColor='F8DCDA')
for _,x in cross_keep.iterrows():
    vals=[x['搜索词(归一化)'],x['匹配状态'],int(x['n_asins']),int(x['vol']),int(x['sqp_impr']),int(x['sqp_clk']),int(x['sqp_add']),int(x['sqp_ord']),
          int(x['ad_impr']),int(x['ad_clk']),round(x['ad_spend'],2),round(x['ad_sales'],2),int(x['ad_ord']),
          f'=IF(F{r}=0,"",J{r}/F{r})',f'=IF(H{r}=0,"",M{r}/H{r})',f'=MAX(F{r}-J{r},0)',f'=MAX(H{r}-M{r},0)',
          f'=IF(AND(F{r}>0,J{r}>F{r}),"广告>SQP,口径不一致",IF(F{r}=0,"SQP未收录长尾",IF(J{r}=0,"未投广告/纯自然","可估算自然占比")))']
    datarow(ws,r,vals,formats={3:INT,4:INT,5:INT,6:INT,7:INT,8:INT,9:INT,10:INT,11:MONEY,12:MONEY,13:INT,14:PCT,15:PCT,16:INT,17:INT})
    if x['sqp_clk']>0 and x['ad_clk']>x['sqp_clk']:
        for cc in range(1,len(cols8)+1): ws.cell(r,cc).fill=warn_fill
    r+=1
ws.freeze_panes='C4'
ws.auto_filter.ref=f'A3:{get_column_letter(len(cols8))}{r-1}'

# ================= 09 口径差异 =================
ws=wb.create_sheet('09_口径差异与脱敏'); ws.sheet_view.showGridLines=False
setw(ws,[16,34,34,40]); r=1
title(ws,r,4,'口径差异、亚马逊脱敏机制与使用注意事项'); r+=2
hdr(ws,r,['对比维度','SQP 搜索查询绩效','SP 广告搜索词报告','对“比例”分析的影响']); r+=1
diffs=[
 ('数据性质','全市场所有卖家的汇总 + 你ASIN的份额；自然流量与广告流量合并','只有本店铺付费广告的数据','理论上SQP自家数应≥广告数；实际反超即说明其他口径不一致'),
 ('搜索词收录范围','每个ASIN仅导出排名前100的词（27/51个ASIN达到上限）；低流量词按隐私阈值剔除；归一化后共2,410个词','全量43,846个词（原始写法43,847，双空格等归一化后合并），含自动广告的海量长尾','集合勾稽：共有1,802、仅SQP 608、仅广告42,044；42,044个广告词在SQP中完全无此词，占广告点击64.4%、订单53.2%、花费56.9%、销售额52.9%，是比例失真首因；另有26个共有词你家SQP零点击（广告仅122点击/7单）'),
 ('商品(ASIN)范围','仅51个已导出ASIN','全店铺在投商品，含未导出SQP的21个变体/新品及其他产品线','广告落地的部分ASIN不在SQP范围，广告数会偏大'),
 ('归因口径','按搜索当次统计：官方规定从查询到展示/点击/加购/购买全环节须在查询后24小时内完成，当天加购、次日才购买不计入该词归因','点击后7天内的成交均归因给广告，可跨日、跨词','归因窗口24小时 vs 7天；月末几天成交广告侧偏多，同一笔成交两表归属可能不同'),
 ('数值精度','份额四舍五入到0.01%，小数值屏蔽/模糊；实测由份额反推自家曝光与整数计数最大相差约1,461次、点击约18次、订单约1次','精确整数与两位小数','SQP为近似值，极小值对比无意义'),
 ('时间粒度','按月（2026-09整月，报告日期2026-09-30）','按日（9/1–9/30）','月度合计可对齐；无法做日度对比'),
 ('“率”的分母','搜索词报告（本次CSV）：CTR＝点击÷搜索查询量、加购率＝加购÷搜索量、购买率＝购买÷搜索量；全系商品报告：CTR＝点击÷展示、转化率＝购买÷点击','广告报告：CTR＝点击÷展示、CVR＝订单÷点击','同名“点击率/转化率”分母随报告不同，严禁直接相减或相比')]
for rr in diffs:
    datarow(ws,r,list(rr)); ws.row_dimensions[r].height=70; r+=1
r+=1
section(ws,r,4,'亚马逊“处理数据、防止泄露”具体指什么'); r+=1
notes=['1. 只给市场总量、不给竞品明细：你能看到某个词全市场的曝光/点击/成交总量，以及“你自己”的计数和份额，但看不到任何具体竞品ASIN的数字。',
 '2. 份额百分比只保留到0.01%：由“总量×份额”反推任一卖家的绝对值会有误差，配合小数值屏蔽，避免反推出竞品或小卖家的真实经营数据。',
 '3. 隐私阈值：搜索量过低、涉及长尾或敏感的词不展示或合并，样本不足时数据留空。',
 '4. 数据有更新延迟且为估算口径：月末报表可能在次月才稳定，部分数值为模型估算。',
 '5. 本次导出未见“区间值”（如1–10），所有计数为整数，但仍受上述精度与阈值影响。']
for t in notes: para(ws,r,4,t,size=10,h=30); r+=1
r+=1
section(ws,r,4,'建议的正确用法'); r+=1
uses=['① 看市场与竞争：用05表漏斗份额、04表分ASIN份额，判断你在各环节的市场地位。',
 '② 看词的打法：用08表把头部词分成“自然型大词”（控花费）和“广告型精准词”（保排名、盯ACOS）。',
 '③ 估算自然量：仅在双方共有且广告≤SQP的词上，用 SQP自家−广告 近似自然量；标红行不要反推。',
 '④ 补齐数据：SQP按1,000条/ASIN重新导出；广告报告申请增加推广ASIN/SKU字段；如投放了SB/SD广告需一并导出。']
for t in uses: para(ws,r,4,t,size=10,h=30); r+=1

# ================= 10 图表 =================
wsc=wb.create_sheet('10_图表'); wsc.sheet_view.showGridLines=False
setw(wsc,[14]*14)
title(wsc,1,14,'图表（数据源：05漏斗 / 07每日 / 06产品线 / 08头部词）')
# chart1 funnel (点击/加购/下单 市场vs自家)
ch1=BarChart(); ch1.type='col'; ch1.title='漏斗对比：全市场 vs 自家（点击/加购/下单，9月）'; ch1.height=8; ch1.width=15
data=Reference(wb['05_SQP_漏斗'],min_col=2,min_row=6,max_row=8)
data2=Reference(wb['05_SQP_漏斗'],min_col=5,min_row=6,max_row=8)
cats=Reference(wb['05_SQP_漏斗'],min_col=1,min_row=6,max_row=8)
ch1.add_data(data,titles_from_data=False); ch1.add_data(data2,titles_from_data=False)
ch1.set_categories(cats)
ch1.series[0].graphicalProperties.solidFill='9DB7D6'; ch1.series[1].graphicalProperties.solidFill=DARK
from openpyxl.chart.series import SeriesLabel
ch1.series[0].tx=SeriesLabel(v='全市场'); ch1.series[1].tx=SeriesLabel(v='自家(51个ASIN)')
wsc.add_chart(ch1,'A3')
# chart2 daily spend vs sales
ch2=LineChart(); ch2.title='每日广告花费 vs 7天销售额（9月）'; ch2.height=8; ch2.width=15
d_sp=Reference(wb['07_广告_每日趋势'],min_col=6,min_row=3,max_row=33)
d_sa=Reference(wb['07_广告_每日趋势'],min_col=7,min_row=3,max_row=33)
catsd=Reference(wb['07_广告_每日趋势'],min_col=1,min_row=4,max_row=33)
ch2.add_data(d_sp,titles_from_data=True); ch2.add_data(d_sa,titles_from_data=True); ch2.set_categories(catsd)
ch2.series[0].graphicalProperties.line.solidFill=WARN; ch2.series[1].graphicalProperties.line.solidFill=GOOD
wsc.add_chart(ch2,'H3')
# chart3 top10 portfolio spend vs sales
ch3=BarChart(); ch3.type='col'; ch3.title='各产品线广告花费 vs 销售额（Top10，按花费）'; ch3.height=8; ch3.width=15
d3a=Reference(wb['06_广告_产品线与匹配'],min_col=7,min_row=4,max_row=14)
d3b=Reference(wb['06_广告_产品线与匹配'],min_col=8,min_row=4,max_row=14)
cats3=Reference(wb['06_广告_产品线与匹配'],min_col=1,min_row=5,max_row=14)
ch3.add_data(d3a,titles_from_data=True); ch3.add_data(d3b,titles_from_data=True); ch3.set_categories(cats3)
ch3.series[0].graphicalProperties.solidFill='E0A040'; ch3.series[1].graphicalProperties.solidFill=GOOD
wsc.add_chart(ch3,'A20')
# chart4 top15 head terms sqp clk vs ad clk
ch4=BarChart(); ch4.type='bar'; ch4.title='Top15头部搜索词：SQP自家点击 vs 广告点击'; ch4.height=10; ch4.width=15
d4a=Reference(wb['08_搜索词交叉对比'],min_col=6,min_row=3,max_row=18)
d4b=Reference(wb['08_搜索词交叉对比'],min_col=10,min_row=3,max_row=18)
cats4=Reference(wb['08_搜索词交叉对比'],min_col=1,min_row=4,max_row=18)
ch4.add_data(d4a,titles_from_data=True); ch4.add_data(d4b,titles_from_data=True); ch4.set_categories(cats4)
ch4.series[0].graphicalProperties.solidFill='9DB7D6'; ch4.series[1].graphicalProperties.solidFill=WARN
wsc.add_chart(ch4,'H20')

wb.save(out)
print('SAVED', out)
print('market totals:',mkt_tot)
print('own totals:',own_tot)
print('shares impr/clk/add/ord: %.4f %.4f %.4f %.4f'%(own_tot['impr']/mkt_tot['impr'],own_tot['clk']/mkt_tot['clk'],own_tot['add']/mkt_tot['add'],own_tot['ord']/mkt_tot['ord']))
