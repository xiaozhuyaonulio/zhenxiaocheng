# -*- coding: utf-8 -*-
import pickle
P = pickle.load(open(r'C:\Users\adm\Desktop\gaoxiaocheng\_prep.pkl','rb'))
a = P['asin_sum']; mt = P['mkt_tot']
print('04表合计行(逐ASIN相加) 市场搜索量/曝光/点击/加购/下单:')
print(int(a['市场搜索查询量(覆盖词)'].sum()), int(a['市场曝光总量'].sum()), int(a['市场点击总量'].sum()), int(a['市场加购总量'].sum()), int(a['市场下单总量'].sum()))
print('05表按词去重后真实市场总量:')
print(int(mt['vol']), int(mt['impr']), int(mt['clk']), int(mt['add']), int(mt['ord']))
print('04合计行 自家(应正确):', int(a['自家曝光'].sum()), int(a['自家点击'].sum()), int(a['自家加购'].sum()), int(a['自家下单'].sum()))
print('05自家:', int(P['own_tot']['impr']), int(P['own_tot']['clk']), int(P['own_tot']['add']), int(P['own_tot']['ord']))
