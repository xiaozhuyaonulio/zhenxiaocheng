# -*- coding: utf-8 -*-
import pandas as pd, glob, os
d=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效'
f=os.path.join(d,'B0CN4MVL5L.csv')
df=pd.read_csv(f, skiprows=1)
print('cols:')
for c in df.columns: print(' -', c)
row=df[df.iloc[:, df.columns.get_loc([c for c in df.columns if '搜索查询' in c][0])].astype(str).str.strip().str.lower()=='pasta jars with lids multi size']
pd.set_option('display.max_columns', None); pd.set_option('display.width', 300)
print('\nROW:')
for c in df.columns:
    print(c, '=', row.iloc[0][c])
