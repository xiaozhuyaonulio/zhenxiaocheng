# -*- coding: utf-8 -*-
import pandas as pd
from openpyxl import load_workbook
base = r'C:\Users\adm\Desktop\gaoxiaocheng'

# 1) 广告报告所有文本列里找“塑料”
ad = pd.read_excel(base + r'\raw_data\26.9.xlsx', sheet_name='商品推广_搜索词_报告')
for c in ad.columns:
    s = ad[c].dropna().astype(str)
    h = s[s.str.contains('塑料')]
    if len(h):
        print('广告报告列 [%s] 命中:' % c, sorted(set(h))[:10])

# 2) 我交付的两个xlsx里找“塑料袋/塑料”
for fn in ['9月搜索数据整体分析.xlsx', 'SQP搜索查询绩效_51个ASIN合并总表.xlsx']:
    wb = load_workbook(base + '\\' + fn, read_only=True)
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            for v in row:
                if isinstance(v, str) and '塑料' in v:
                    print(fn, ws.title, '->', v)
    wb.close()

# 3) 04表里 B0CN4NHCDP 这一行的产品线到底是什么
wb = load_workbook(base + r'\9月搜索数据整体分析.xlsx', data_only=False)
ws = wb['04_SQP_ASIN汇总']
hdr = [c.value for c in ws[2]]
for row in ws.iter_rows(min_row=3, max_row=53, values_only=True):
    if row[0] == 'B0CN4NHCDP':
        for k, v in zip(hdr, row):
            print(k, '=', v)
