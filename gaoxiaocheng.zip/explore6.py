# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, os, re, glob
pd.set_option('display.max_columns', None); pd.set_option('display.width', 320); pd.set_option('display.max_colwidth', 60)
base=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'; cd=base+r'\产品9月份搜索查询绩效'
frames=[]
for f in glob.glob(cd+r'\*.csv'):
    d=pd.read_csv(f, skiprows=1, dtype=str); d['ASIN']=os.path.basename(f)[:-4]; frames.append(d)
sqp=pd.concat(frames, ignore_index=True)
ad=pd.read_excel(base+r'\26.9.xlsx')
for c in ['展示量','点击量','花费','7天总销售额','7天总订单数(#)']: ad[c]=pd.to_numeric(ad[c],errors='coerce').fillna(0)
num=lambda c: pd.to_numeric(sqp[c],errors='coerce')
for c in ['搜索查询量','曝光：曝光总量','曝光量：ASIN 计数','曝光：ASIN 曝光占比 %','点击量：总次数','点击量：ASIN 数量','点击量：ASIN 份额 %','购物车添加：总数','加购：ASIN 数量','购买：下单总数','下单成交：ASIN 数量','下单: ASIN 占比 %']:
    sqp[c]=num(c)

# 1. 100-row cap
cnt=sqp.groupby('ASIN').size()
print('files with exactly 100 rows (truncated at top100):', (cnt==100).sum(), '/', len(cnt))
print('files rows distribution:', cnt.value_counts().sort_index().to_dict())
print()

# 2. rounding check: implied own = total*share/100 vs reported own
sqp['imp_own_impr']=(sqp['曝光：曝光总量']*sqp['曝光：ASIN 曝光占比 %']/100).round(2)
sqp['imp_own_clk']=(sqp['点击量：总次数']*sqp['点击量：ASIN 份额 %']/100).round(2)
sqp['imp_own_ord']=(sqp['购买：下单总数']*sqp['下单: ASIN 占比 %']/100).round(2)
for a,b in [('imp_own_impr','曝光量：ASIN 计数'),('imp_own_clk','点击量：ASIN 数量'),('imp_own_ord','下单成交：ASIN 数量')]:
    diff=(sqp[a]-sqp[b]).abs()
    print('rounding %s: max abs diff %.2f, rows diff>0.55: %d / %d'%(a, diff.max(), (diff>0.55).sum(), len(sqp)))
print()

# 3. brand-level SQP aggregation
def norm(s): return re.sub(r'\s+',' ',str(s).strip().lower())
sqp['q']=sqp['搜索查询'].apply(norm)
bs=sqp.groupby('q').agg(sqp_impr=('曝光量：ASIN 计数','sum'), sqp_clk=('点击量：ASIN 数量','sum'),
                        sqp_add=('加购：ASIN 数量','sum'), sqp_ord=('下单成交：ASIN 数量','sum'),
                        mkt_impr=('曝光：曝光总量','sum'), mkt_clk=('点击量：总次数','sum'),
                        mkt_ord=('购买：下单总数','sum'), n_asins=('ASIN','nunique'),
                        vol=('搜索查询量','max')).reset_index()
ad['q']=ad['客户搜索词'].dropna().apply(norm)
ba=ad.groupby('q').agg(ad_impr=('展示量','sum'), ad_clk=('点击量','sum'), ad_spend=('花费','sum'),
                       ad_sales=('7天总销售额','sum'), ad_ord=('7天总订单数(#)','sum'),
                       ad_units=('7天总销售量(#)','sum')).reset_index()
m=bs.merge(ba, on='q', how='inner')
print('matched terms:', len(m))
print('SUM on matched terms:')
print('  SQP own impr/clk/add/ord: %.0f %.0f %.0f %.0f'%(m.sqp_impr.sum(),m.sqp_clk.sum(),m.sqp_add.sum(),m.sqp_ord.sum()))
print('  AD        impr/clk/ord:   %.0f %.0f %.0f'%(m.ad_impr.sum(),m.ad_clk.sum(),m.ad_ord.sum()))
print('  AD spend %.0f sales %.0f'%(m.ad_spend.sum(),m.ad_sales.sum()))
print('  >> ad clicks / SQP own clicks = %.1f%%'%(100*m.ad_clk.sum()/m.sqp_clk.sum()))
print('  >> ad orders / SQP own orders = %.1f%%'%(100*m.ad_ord.sum()/m.sqp_ord.sum()))
print('  >> ad impr  / SQP own impr   = %.1f%%'%(100*m.ad_impr.sum()/m.sqp_impr.sum()))
# per-term ratio distribution (where SQP own >0)
for k in [('clk','sqp_clk','ad_clk'),('ord','sqp_ord','ad_ord')]:
    name,sc,ac=k
    x=m[m[sc]>0].copy(); x['r']=x[ac]/x[sc]
    print('per-term ad/SQP %s ratio: median %.2f, mean %.2f, terms ratio>1: %d/%d (%.0f%%)'%(
        name, x.r.median(), x.r.mean(), (x.r>1).sum(), len(x), 100*(x.r>1).mean()))
print()
# 4. examples: top SQP own-click terms with their ad counterpart
ex=m.sort_values('sqp_clk',ascending=False).head(15)[['q','vol','sqp_impr','sqp_clk','sqp_add','sqp_ord','ad_impr','ad_clk','ad_ord','ad_spend','ad_sales','n_asins']]
print(ex.to_string(index=False))
print()
# 5. SQP totals overall (own, across 51 asins) and market totals
print('SQP TOTAL own: impr %.0f clk %.0f add %.0f ord %.0f'%(sqp['曝光量：ASIN 计数'].sum(),sqp['点击量：ASIN 数量'].sum(),sqp['加购：ASIN 数量'].sum(),sqp['下单成交：ASIN 数量'].sum()))
print('SQP TOTAL market: impr %.0f clk %.0f add %.0f ord %.0f'%(sqp['曝光：曝光总量'].sum(),sqp['点击量：总次数'].sum(),sqp['购物车添加：总数'].sum(),sqp['购买：下单总数'].sum()))
