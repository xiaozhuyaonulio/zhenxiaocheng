# -*- coding: utf-8 -*-
import pandas as pd, re
ad=pd.read_excel(r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\26.9.xlsx')
col='客户搜索词'
print('总行数:',len(ad))
print('空搜索词行数:', ad[col].isna().sum())
print('原始不重复:', ad[col].nunique())
def norm(s): return re.sub(r'\s+',' ',str(s).strip().lower())
ad['q']=ad[col].dropna().apply(norm)
# 找归一化后合并的原始词对
g=ad.dropna(subset=['q']).groupby('q')[col].agg(lambda x: sorted(set(x)))
dup=g[g.apply(len)>1]
print('归一化造成合并的词组数:',len(dup))
for q,v in dup.items(): print(' 归一化后=',repr(q),' 原始写法=',v)
# 交集里按点击细分
import glob,os
fr=[]
for f in glob.glob(r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效\*.csv'):
    d=pd.read_csv(f,skiprows=1,dtype=str); fr.append(d)
sqp=pd.concat(fr,ignore_index=True)
sqp['q']=sqp['搜索查询'].apply(norm)
sqp['oc']=pd.to_numeric(sqp['点击量：ASIN 数量'],errors='coerce')
ad['点击量']=pd.to_numeric(ad['点击量'],errors='coerce')
bs=sqp.groupby('q').oc.sum(); ba=ad.groupby('q')['点击量'].sum()
S=set(sqp.q); A=set(ad.q)
inter=S&A
import numpy as np
b=sum(1 for q in inter if bs.get(q,0)>0 and ba.get(q,0)>0)
x=sum(1 for q in inter if bs.get(q,0)>0 and ba.get(q,0)==0)
y=sum(1 for q in inter if bs.get(q,0)==0 and ba.get(q,0)>0)
z=sum(1 for q in inter if bs.get(q,0)==0 and ba.get(q,0)==0)
print('\n交集1802拆解: 双方有点击%d, SQP有点击广告0点击%d, SQP0点击广告有点击%d, 双方都0点击%d'%(b,x,y,z), '合计',b+x+y+z)
w=sum(1 for q in (S-A) if bs.get(q,0)==0)
print('仅SQP集合608中自家0点击的词:',w,' 有自家点击:',608-w)
