# -*- coding: utf-8 -*-
from PIL import Image
import os
src=r'C:\Users\adm\AppData\Local\Doubao\User Data\ClipboardTemp\6e8267ab-6d97-4b7c-afc2-e02e50dd5f44.png'
outdir=r'C:\Users\adm\Desktop\gaoxiaocheng\gloss_crops'
os.makedirs(outdir,exist_ok=True)
im=Image.open(src)
W,H=im.size
print('size',W,H)
seg=3300
i=0; y=0
while y<H:
    y2=min(y+seg,H)
    im.crop((0,y,W,y2)).save(os.path.join(outdir,f'crop_{i:02d}.png'))
    print(i,y,y2)
    i+=1; y=y2
