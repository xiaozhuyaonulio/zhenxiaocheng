# -*- coding: utf-8 -*-
import pandas as pd
base = r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data'
mp = pd.read_excel(base + r'\对应关系.xlsx')
hits = mp[mp['品名'].astype(str).str.contains('圆形')]
print('=== 对应关系表里含“圆形”的行 ===')
print(hits[['ASIN','品名','颜色','规格']].to_string(index=False))

ad = pd.read_excel(base + r'\26.9.xlsx')
print('\n=== 广告报告里含“塑料”的广告组合名称 ===')
ports = ad['广告组合名称'].dropna().astype(str)
for p in sorted(set(ports[ports.str.contains('塑料')])):
    print(repr(p))
print('\n=== 广告报告里含“圆形/储存/储物”的广告组合名称 ===')
for p in sorted(set(ports[ports.str.contains('圆形|储存|储物')])):
    print(repr(p))
