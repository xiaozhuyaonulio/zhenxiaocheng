# -*- coding: utf-8 -*-
import pandas as pd, glob, re
def norm(s): return re.sub(r'\s+',' ',str(s).strip().lower())
fr=[]
for f in glob.glob(r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效\*.csv'):
    d=pd.read_csv(f,skiprows=1,dtype=str); fr.append(d)
sqp=pd.concat(fr,ignore_index=True); sqp['q']=sqp['搜索查询'].apply(norm)
sqp['oc']=pd.to_numeric(sqp['点击量：ASIN 数量'],errors='coerce')
ad=pd.read_excel(r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\26.9.xlsx')
ad['q']=ad['客户搜索词'].dropna().apply(norm)
for c in ['点击量','7天总订单数(#)','花费','7天总销售额']: ad[c]=pd.to_numeric(ad[c],errors='coerce')
bs=sqp.groupby('q').oc.sum()
S=set(sqp.q)
T=ad['点击量'].sum(); O=ad['7天总订单数(#)'].sum(); SP=ad['花费'].sum(); SA=ad['7天总销售额'].sum()
# 口径1：词根本不在SQP集合里
m1=~ad['q'].isin(S)
# 口径2：不在集合 或 在集合但自家0点击
ocmap=bs.reindex(ad['q']).fillna(0).values
m2=(~ad['q'].isin(S)) | (ocmap==0)
for name,m in [('42,044 完全未收录',m1),('42,083 SQP自家0点击桶',m2)]:
    x=ad[m]
    print('%s: 词数%d 点击%.1f%% 订单%.1f%% 花费%.1f%% 销售额%.1f%%'%(
        name, x['q'].nunique(), x['点击量'].sum()/T*100, x['7天总订单数(#)'].sum()/O*100,
        x['花费'].sum()/SP*100, x['7天总销售额'].sum()/SA*100))
# 39个差额词的广告体量
x=ad[ad['q'].isin(S) & (ocmap==0)]
print('差额39词: 广告点击%d 订单%d 花费%.0f 销售额%.0f'%(x['点击量'].sum(),x['7天总订单数(#)'].sum(),x['花费'].sum(),x['7天总销售额'].sum()))
