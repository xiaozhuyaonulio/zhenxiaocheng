# -*- coding: utf-8 -*-
import zipfile, re, sys
from xml.etree import ElementTree as ET

def read_xlsx_basic(path, max_rows=15):
    z = zipfile.ZipFile(path)
    names = z.namelist()
    # shared strings
    shared = []
    if 'xl/sharedStrings.xml' in names:
        root = ET.fromstring(z.read('xl/sharedStrings.xml'))
        ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        for si in root.findall('m:si', ns):
            text = ''.join(t.text or '' for t in si.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'))
            shared.append(text)
    # workbook sheets
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    ns = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
          'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    sheets = []
    for s in wb.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet'):
        sheets.append((s.get('name'), s.get('sheetId'), s.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')))
    print('FILE:', path)
    print('SHEETS:', sheets)
    sheet_files = sorted([n for n in names if re.match(r'xl/worksheets/sheet\d+\.xml', n)])
    print('WORKSHEET FILES:', sheet_files)
    for sf in sheet_files:
        data = z.read(sf).decode('utf-8', errors='ignore')
        dim = re.search(r'<dimension ref="([^"]+)"', data)
        print('---', sf, 'dimension:', dim.group(1) if dim else '?', 'size(KB):', round(len(data)/1024))
    z.close()

for p in [r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\对应关系.xlsx',
          r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\26.9.xlsx']:
    try:
        read_xlsx_basic(p)
    except Exception as e:
        print('ERR', p, e)
    print('='*80)
