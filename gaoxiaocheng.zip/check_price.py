# -*- coding: utf-8 -*-
import pandas as pd
p=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效\B0CN4MVL5L.csv'
df=pd.read_csv(p, skiprows=1)
df.columns=[c.strip() for c in df.columns]
a='点击量：价格(中位数)'; b='点击量：ASIN 售价（中位数）'
d=df[['搜索查询','点击量：总次数','点击量：ASIN 数量',a,b]].dropna(subset=[a])
print('有点击价格中位数的行数:', len(d))
print('两列相等的行数:', (d[a]==d[b]).sum(), ' 不相等的行数:', (d[a]!=d[b]).sum())
print('\n不相等的例子（市场中位价 vs 你家售价）:')
print(d[d[a]!=d[b]].head(10).to_string(index=False))
print('\n你家ASIN售价中位数的取值分布:')
print(d[b].value_counts().head())
print('\n市场点击中位价的取值分布(前10):')
print(d[a].value_counts().head(10))
