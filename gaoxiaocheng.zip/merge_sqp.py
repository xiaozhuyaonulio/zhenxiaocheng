# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, glob, os
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

d=r'C:\Users\adm\Desktop\gaoxiaocheng\raw_data\产品9月份搜索查询绩效'
out=r'C:\Users\adm\Desktop\gaoxiaocheng\SQP搜索查询绩效_51个ASIN合并总表.xlsx'
files=sorted(glob.glob(os.path.join(d,'*.csv')))
frames=[]
for f in files:
    asin=os.path.splitext(os.path.basename(f))[0]
    x=pd.read_csv(f, skiprows=1)
    x.columns=[c.strip() for c in x.columns]
    x.insert(0,'ASIN',asin)
    frames.append(x)
df=pd.concat(frames, ignore_index=True)
print('文件数:',len(files))
print('合并后总行数:',len(df))
print('列数:',len(df.columns))
print('不重复ASIN:',df['ASIN'].nunique())
print('不重复搜索词:',df['搜索查询'].nunique())
# 同一词在不同文件里搜索查询量是否一致
vol_nunique=df.groupby('搜索查询')['搜索查询量'].nunique()
print('搜索量跨文件不一致的词数:', (vol_nunique>1).sum())

# sheet2: 不重复搜索词清单
g=df.groupby('搜索查询').agg(出现ASIN数=('ASIN','nunique'), 搜索查询量=('搜索查询量','max')).reset_index()
g=g.sort_values('搜索查询量',ascending=False)
print('不重复词清单行数:',len(g))

with pd.ExcelWriter(out, engine='openpyxl') as w:
    df.to_excel(w, sheet_name='合并明细(3117行)', index=False)
    g.to_excel(w, sheet_name='不重复搜索词(2410个)', index=False)

# ---- 样式 ----
wb=load_workbook(out)
DARK='17365D'; MID='2E5E9C'; FONT='微软雅黑'
thin=Side(style='thin',color='B8C7D9'); border=Border(left=thin,right=thin,top=thin,bottom=thin)
pct_cols=[c for c in df.columns if '%' in c]
price_cols=[c for c in df.columns if '价格' in c or '售价' in c]
for sn,dfx in [('合并明细(3117行)',df),('不重复搜索词(2410个)',g)]:
    ws=wb[sn]; ws.sheet_view.showGridLines=False
    ncol=dfx.shape[1]
    for j,c in enumerate(dfx.columns,1):
        cell=ws.cell(1,j)
        cell.font=Font(name=FONT,bold=True,size=10,color='FFFFFF')
        cell.fill=PatternFill('solid',fgColor=MID)
        cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
        cell.border=border
        # 列宽
        if c=='搜索查询': w=34
        elif c=='ASIN': w=13
        elif '%' in c: w=13
        elif '配送' in c: w=14
        elif '价格' in c or '售价' in c: w=16
        elif c=='报告日期': w=12
        elif '得分' in c: w=9
        else: w=12
        ws.column_dimensions[get_column_letter(j)].width=w
    ws.row_dimensions[1].height=32
    ws.freeze_panes='B2' if sn.startswith('合并') else 'A2'
    ws.auto_filter.ref=f'A1:{get_column_letter(ncol)}{ws.max_row}'
    # 数字格式（%列原值已是百分点数值，如3.36=3.36%，不能套百分比格式）
    headers=[c.value for c in ws[1]]
    for j,c in enumerate(headers,1):
        L=get_column_letter(j)
        if c in pct_cols or c in price_cols:
            for cell in ws[L][1:]: cell.number_format='0.00'
        elif c not in ('ASIN','搜索查询','报告日期'):
            for cell in ws[L][1:]: cell.number_format='#,##0'
wb.save(out)
print('SAVED',out)
